# BÁO CÁO DỊCH NGƯỢC CHI TIẾT - APK LOCMOD V11 PROXY
> **Deobfuscated & Analyzed by TDINH**  
> **Target File:** `input/LocMod_V11 Proxy.apk` (39.2 MB)  
> **Ngày phân tích:** 01/11/2026

---

## 1. TỔNG QUAN ỨNG DỤNG
* **Tên ứng dụng:** PROXY KAUAN / LocMod V11 Proxy (`game-telemetry-monitor`)
* **Package Name:** `com.dts.freefiremth`
* **Version:** 32.0.7
* **Mục tiêu can thiệp:** Game Garena Free Fire / Free Fire MAX (`com.dts.freefiremax`, `com.dts.freefireth`)
* **Kiến trúc công nghệ:**
  * **Frontend:** React Native (Expo) biên dịch qua **Hermes Bytecode v96 (HBC 96)**.
  * **Native Backend (Android):** Java Native DEX (`classes.dex`, `classes2.dex`, `classes3.dex`).
  * **Native Security & Engine (C/C++):** `libmthguard.so`, `libmthpayload.so`, `libmthsecurity.so` (ARM64-v8a).
  * **Game In-Memory Patch:** Unity IFix Bridge (`assets/payload`).

---

## 2. HỆ THỐNG XÁC THỰC & SERVER GET KEY (CLASSES3.DEX)
Giao diện đăng nhập và kiểm tra bản quyền được quản lý bởi package `com.locmod.proxy`:

* **Activity Đăng nhập:** `com.locmod.proxy.LoginActivity` (có hiệu ứng Star background, EyeToggle ẩn/hiện mật khẩu).
* **API Xác thực (Verify Key):**
  ```text
  https://hihidex.x10.mx/api/?action=verify&user_key={KEY_CUA_BAN}
  ```
* **Link Lấy Key (Get Key):**
  ```text
  https://hihidex.x10.mx/index.php?page=getkey&admin=hihidev
  ```
* **Server Quản trị / Dashboard Key dự phòng:**
  ```text
  http://dowloadapp.top/genkey/dashboard.php
  ```
* **Cơ chế lưu phiên (Session Storage):**
  * Lưu vào Android SharedPreferences: `loc_proxy_auth`
  * Khóa lưu hạn dùng: `authorizedUntil` (timestamp mili-giây)
* **Bảo mật SSL Pinning (`SxTls`):**
  * Tích hợp TrustManager riêng nhúng sẵn 2 chứng chỉ SSL CA: **ISRG Root X1** và **Root YR (Let's Encrypt)** để chống bắt gói tin proxy thông thường qua Burp Suite / Fiddler nếu chưa cài chứng chỉ hệ thống.

---

## 3. CƠ CHẾ CAN THIỆP GAME (REACT NATIVE & NATIVE PAYLOAD)

### A. React Native Hermes Bundle (`decompiled_index.js`)
* Bundle JavaScript gốc `assets/index.android.bundle` (Hermes Bytecode v96) đã được dịch ngược toàn bộ thành file [`decompiled_index.js`](file:///d:/THAY%20THẾ/deobf/output/LocMod_V11_Proxy/decompiled_index.js) (dung lượng **21.52 MB**).
* **Các module quan trọng:**
  * `TelemetryProvider` & `useTelemetry`: Quản lý state theo dõi dữ liệu telemetry của người chơi trong game.
  * `UdpTelemetry`: Module tương tác socket UDP ở cổng `27020` và `3500`.
  * `beginAdbPairing` & `MthAdbPairingReceiver`: Cơ chế ghép nối qua ADB không dây (Wireless ADB) để cấp quyền hệ thống mà không cần root.
  * `manusfreefiremth`: Scheme deep link URL cho ứng dụng.

### B. Native Security Libraries (`lib_arm64/`)
* **`libmthguard.so`:**
  * Xuất các hàm JNI JNIEnv:
    * `Java_expo_modules_udptelemetry_NativeRuntimeGuard_nativeLeaseValid`
    * `Java_expo_modules_udptelemetry_NativeRuntimeGuard_nativeDeviceId`
    * `Java_expo_modules_udptelemetry_NativeRuntimeGuard_nativeSessionExpiry`
    * `Java_expo_modules_udptelemetry_NativeRuntimeGuard_nativeAuthenticatedKey`
  * Chức năng: Kiểm tra tính toàn vẹn của thiết bị, thời hạn phiên đăng nhập và khóa xác thực trước khi cho phép dữ liệu đi qua.
* **`libmthpayload.so`:**
  * Hàm `Java_expo_modules_udptelemetry_ProtectedAssembly_nativeRead` và `mth_guard_verify`.
* **`libmthsecurity.so`:**
  * Cầu nối `expo/modules/udptelemetry/MthSecurityBridge` kết nối tới máy chủ `https://mthteam...`.

### C. Game Hotfix Patch (`payload`)
* File `assets/payload` chứa bytecode patch của framework **Tencent IFix**:
  * Target: `dIFix.ILFixInterfaceBridge, Assembly-CSharp, Version=0.86.0.518`
  * Đây là mã bytecode được nạp nóng vào engine Unity (`Assembly-CSharp.dll`) của game Free Fire để hook và thay đổi hành vi nhân vật / đường đạn / tốc độ.

---

## 4. DANH MỤC TÀI LIỆU & FILE TRÍCH XUẤT TRONG `output/LocMod_V11_Proxy/`

| Tên File | Dung lượng | Mô tả |
| :--- | :--- | :--- |
| [`decompiled_index.js`](file:///d:/THAY%20THẾ/deobf/output/LocMod_V11_Proxy/decompiled_index.js) | 21.5 MB | Toàn bộ mã nguồn JavaScript React Native đã decompile từ Hermes bytecode v96 |
| [`app.config`](file:///d:/THAY%20THẾ/deobf/output/LocMod_V11_Proxy/app.config) | 1.5 KB | Cấu hình Expo, scheme URL, bundle id |
| [`localConfig.json`](file:///d:/THAY%20THẾ/deobf/output/LocMod_V11_Proxy/localConfig.json) | 22 B | Cờ `testCodePatch: true` |
| [`payload`](file:///d:/THAY%20THẾ/deobf/output/LocMod_V11_Proxy/payload) | 56.8 KB | Bytecode IFix Hook dành cho Free Fire Unity Assembly-CSharp |
| `lib_arm64/` | ~1.1 MB | Các thư viện native JNI (`libmthguard.so`, `libmthpayload.so`, `libmthsecurity.so`) |
