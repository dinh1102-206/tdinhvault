@echo off
setlocal
title AIOLauncher - Reset Qt/QML Cache
echo ============================================================
echo   AIOLauncher Cache Reset
echo ============================================================
echo.
echo Closing running instances...
taskkill /F /IM AIOLauncher.exe >nul 2>nul
taskkill /F /IM AegisubModern.exe >nul 2>nul
taskkill /F /IM "AIO Downloader.exe" >nul 2>nul
timeout /t 1 /nobreak >nul

echo Removing app cache folders...
call :wipe "%LOCALAPPDATA%\AIOLauncher\AIOLauncher v2\cache"
call :wipe "%LOCALAPPDATA%\AIOLauncher\AIOLauncher v2\qmlcache"
call :wipe "%LOCALAPPDATA%\AIOLauncherv2\cache"
call :wipe "%LOCALAPPDATA%\AIOLauncherv2\qmlcache"
call :wipe "%LOCALAPPDATA%\AIOLauncherv2\qml"
call :wipe "%LOCALAPPDATA%\AegisubModern\qmlcache"
call :wipe "%LOCALAPPDATA%\cache\qtshadercache-x86_64-little_endian-llp64"

for /d %%D in ("%LOCALAPPDATA%\AIOLauncher\AIOLauncher v2\cache\qtpipelinecache-*") do call :wipe "%%~fD"
for /d %%D in ("%LOCALAPPDATA%\AIOLauncherv2\cache\qtpipelinecache-*") do call :wipe "%%~fD"

echo Cache reset complete.
echo Press any key to launch AIOLauncher with clean cache settings...
pause >nul
set "QML_DISABLE_DISK_CACHE=1"
set "QT_DISABLE_SHADER_DISK_CACHE=1"
set "QSG_RHI_DISABLE_SHADER_DISK_CACHE=1"
"%~dp0AIOLauncher.exe" %*
endlocal
exit /b 0

:wipe
if exist "%~1" (
  rmdir /s /q "%~1" 2>nul
  if exist "%~1" (
    echo   [WARN] Unable to remove: %~1
  ) else (
    echo   [OK] Removed: %~1
  )
) else (
  echo   [SKIP] Not found: %~1
)
exit /b 0
