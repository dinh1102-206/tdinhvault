--write by editor  EffectSDK:10.9.0 EngineVersion:10.68.0 EditorBuildTime:Apr_26_2022_04_38_07
--sliderVersion: 20210901  Lua generation date: Wed Dec  7 15:43:53 2022


local exports = exports or {}
local ImageBusinessSlider = ImageBusinessSlider or {}
ImageBusinessSlider.__index = ImageBusinessSlider


function ImageBusinessSlider.new(construct, ...)
    local self = setmetatable({}, ImageBusinessSlider)
    if construct and ImageBusinessSlider.constructor then
        ImageBusinessSlider.constructor(self, ...)
    end
    return self
end


local function remap(x, a, b)
    return x * (b - a) + a
end


function ImageBusinessSlider:onStart(sys)
    self.blur2Material0 = sys.scene:findEntityBy("blur2"):getComponent("Renderer").material
    self.Pass2Material1 = sys.scene:findEntityBy("Pass2"):getComponent("Renderer").material
    self.blur1Material2 = sys.scene:findEntityBy("blur1"):getComponent("Renderer").material
    self.blur3Material3 = sys.scene:findEntityBy("blur3"):getComponent("Renderer").material
    self.blur0Material4 = sys.scene:findEntityBy("blur0"):getComponent("Renderer").material
end


function ImageBusinessSlider:onEvent(sys,event)
    if event.args:get(0) == "effects_adjust_size" then
        local intensity = event.args:get(1)
        self.blur2Material0["lineSize"] = remap(intensity,0.3,7.5)
        self.Pass2Material1["sizeFlag"] = remap(intensity,0,1)
        self.blur1Material2["lineSize"] = remap(intensity,0.3,7.5)
        self.blur3Material3["lineSize"] = remap(intensity,0.3,7.5)
        self.blur0Material4["lineSize"] = remap(intensity,0.3,7.5)
    end
    if event.args:get(0) == "effects_adjust_alpha"  then
        local ins = event.args:get(1)
        self.Pass2Material1:setFloat("alpha",ins)
    end
    -- if event.args:get(0) == "effects_adjust_color" then
    --     local intensity = event.args:get(1)
    --     self.Pass2Material1["edgeColOffset"] = remap(intensity,0,1)
    -- end
    -- self.Pass2Material1
end


exports.ImageBusinessSlider = ImageBusinessSlider
return exports