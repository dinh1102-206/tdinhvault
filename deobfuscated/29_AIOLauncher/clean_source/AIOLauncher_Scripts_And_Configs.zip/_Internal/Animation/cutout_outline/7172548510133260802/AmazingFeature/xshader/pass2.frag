precision highp float;

uniform sampler2D orimattingMask;
uniform sampler2D mattingmask;
uniform sampler2D oriTex;
uniform float sizeFlag;

varying vec2 uv;


uniform vec4 u_ScreenParams;
uniform float edgeColOffset;
uniform sampler2D edgeColLine;
uniform float R;
uniform float G;
uniform float B;
uniform float alpha;

void main()
{
    float orimatting = texture2D(orimattingMask,vec2(uv.x,uv.y)).r;

    vec4 upMattingCol = texture2D(mattingmask,vec2(uv.x,1.0-uv.y));
    float upMatting = upMattingCol.r;
    vec4 oriCol = texture2D(oriTex,uv);
    oriCol.rgb = clamp(oriCol.rgb/oriCol.a,0.0,1.0);

    vec3 edgeCol=vec3(R,G,B);

    vec4 myResultCol = oriCol;
    float downIns = 0.05;
    upMatting = smoothstep(downIns,downIns+mix(0.035,0.01,sizeFlag),upMatting);
    // float orimattingIns = 0.8;
    // orimatting = smoothstep(orimattingIns,orimattingIns+mix(0.05,0.03,sizeFlag),orimatting);
    if(oriCol.a>0.)
    myResultCol.rgb = mix(myResultCol.rgb,edgeCol.rgb,upMatting);
    else
    myResultCol.rgb = edgeCol.rgb;

    myResultCol.rgb = mix(myResultCol.rgb,oriCol.rgb,orimatting);
    myResultCol.rgb = clamp(myResultCol.rgb/clamp(oriCol.a+upMatting,0.0,1.0),0.0,1.0);

    float lastAlpha = clamp(oriCol.a+upMatting*alpha,0.0,1.0);
    gl_FragColor = vec4(myResultCol.rgb,lastAlpha);
    //gl_FragColor = bgCol;

    

}
