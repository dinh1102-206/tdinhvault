--write by editor  EffectSDK:12.7.0 EngineVersion:12.7.0 EditorBuildTime:Nov__2_2022_09_58_45
--sliderVersion: 20210901  Lua generation date: Tue Dec  6 14:57:34 2022


local exports = exports or {}
local ImageBusinessSlider = ImageBusinessSlider or {}
ImageBusinessSlider.__index = ImageBusinessSlider


function ImageBusinessSlider.new(construct, ...)
    local self = setmetatable({}, ImageBusinessSlider)
    if construct and ImageBusinessSlider.constructor then
        ImageBusinessSlider.constructor(self, ...)
    end
    return self
end


local function remap(x, a, b)
    return x * (b - a) + a
end


function ImageBusinessSlider:onStart(sys)
    self.blur1Material0 = sys.scene:findEntityBy("blur1"):getComponent("Renderer").material
    self.blur3Material1 = sys.scene:findEntityBy("blur3"):getComponent("Renderer").material
    self.blur0Material2 = sys.scene:findEntityBy("blur0"):getComponent("Renderer").material
    self.blur2Material3 = sys.scene:findEntityBy("blur2"):getComponent("Renderer").material
    self.blurYMaterial4 = sys.scene:findEntityBy("blurY"):getComponent("Renderer").material
    self.blur4Material5 = sys.scene:findEntityBy("blur4"):getComponent("Renderer").material
    self.blur5Material6 = sys.scene:findEntityBy("blur5"):getComponent("Renderer").material
    self.blurXMaterial7 = sys.scene:findEntityBy("blurX"):getComponent("Renderer").material
end


function ImageBusinessSlider:onEvent(sys,event)
    if event.args:get(0) == "effects_adjust_distance" then
        local intensity = event.args:get(1)
        self.blur1Material0["lineSize"] = remap(intensity,0,7)
        self.blur3Material1["sizeFlag"] = remap(intensity,0,1)
        self.blur3Material1["lineSize"] = remap(intensity,0,1)
        self.blur0Material2["lineSize"] = remap(intensity,0,7)
        self.blur2Material3["lineSize"] = remap(intensity,0,7)
    end
    if event.args:get(0) == "effects_adjust_texture" then
        local intensity = event.args:get(1)
        self.blurYMaterial4["sucai0Ins"] = remap(intensity,0,1)
    end
    if event.args:get(0) == "effects_adjust_size" then
        local intensity = event.args:get(1)
        self.blur4Material5["lineSize"] = remap(intensity,0,3)
        self.blur5Material6["lineSize"] = remap(intensity,0,3)
    end
    if event.args:get(0) == "effects_adjust_size" then
        local intensity = event.args:get(1)
        self.blurYMaterial4["lineSize"] = remap(intensity,0,4)
        self.blurXMaterial7["lineSize"] = remap(intensity,0,4)
        -- self.blurYMaterial4["shadowIns"] = remap(intensity,0,1)
    end
end


exports.ImageBusinessSlider = ImageBusinessSlider
return exports