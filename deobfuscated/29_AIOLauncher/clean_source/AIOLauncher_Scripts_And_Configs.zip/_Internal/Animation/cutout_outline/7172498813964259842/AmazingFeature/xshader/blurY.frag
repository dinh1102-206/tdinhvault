precision highp float;

uniform sampler2D oriTex;
uniform sampler2D mattingmask;

varying vec2 uv;

uniform int inputWidth;
uniform int inputHeight;
uniform vec4 u_ScreenParams;
uniform float iTime;
uniform float lineSize;

uniform float edgeColOffset;
uniform sampler2D edgeColLine;
uniform sampler2D sucai1;
uniform sampler2D sucai0;
uniform float sucai0Ins;
uniform float shadowIns;
float blendSoftLight(float base, float blend) {
    return (blend<0.5)?(2.0*base*blend+base*base*(1.0-2.0*blend)):(sqrt(base)*(2.0*blend-1.0)+2.0*base*(1.0-blend));
}

vec3 blendSoftLight(vec3 base, vec3 blend) {
    return vec3(blendSoftLight(base.r,blend.r),blendSoftLight(base.g,blend.g),blendSoftLight(base.b,blend.b));
}


void main()
{
    vec2 mySize = u_ScreenParams.xy/min(u_ScreenParams.x,u_ScreenParams.y)*720.;
    vec2 offset = vec2(1.0,0.0)/mySize;

    vec2 myuv = vec2(uv.x,uv.y);
    vec4 oriMask = texture2D(mattingmask,myuv);
    float half_gaussian_weight[9];
    
    half_gaussian_weight[0]= 0.20;//0.137401;
    half_gaussian_weight[1]= 0.19;//0.125794;
    half_gaussian_weight[2]= 0.17;//0.106483;
    half_gaussian_weight[3]= 0.15;//0.080657;
    half_gaussian_weight[4]= 0.13;//0.054670;
    half_gaussian_weight[5]= 0.11;//0.033159;
    half_gaussian_weight[6]= 0.08;//0.017997;
    half_gaussian_weight[7]= 0.05;//0.008741;
    half_gaussian_weight[8]= 0.02;//0.003799;
    float mask = oriMask.b*half_gaussian_weight[0];
    float num = half_gaussian_weight[0];
    // for(int i=1;i<7;i++){
    //     float j = float(i);
    //     mask += texture2D(mattingmask,myuv+j*offset).r*half_gaussian_weight;
    //     mask += texture2D(mattingmask,myuv-j*offset).r;
    // }
    // mask/=num;
    // upmask/=7.0;
    for(int i=1;i<7;i++){
        float j = float(i);
        mask+= texture2D(mattingmask,myuv+j*lineSize*offset).b*half_gaussian_weight[i];
        mask+= texture2D(mattingmask,myuv-j*lineSize*offset).b*half_gaussian_weight[i];
        num+=2.0*half_gaussian_weight[i];
        
    }
    mask/=num;
    oriMask.b = mask;

    vec2 mask01 = oriMask.rg*half_gaussian_weight[0];
    num = half_gaussian_weight[0];
    for(int i=1;i<4;i++){
        float j = float(i);
        mask01+= texture2D(mattingmask,myuv+0.1*j*offset).rg*half_gaussian_weight[i];
        mask01+= texture2D(mattingmask,myuv-0.1*j*offset).rg*half_gaussian_weight[i]; 
        num+=2.0*half_gaussian_weight[i];     
    }
    mask01/=num;
    oriMask.rg = mask01;

    vec4 oriCol = vec4(texture2D(oriTex,vec2(uv.x,1.0-uv.y)).rgb,1.0);
    vec4 sucai0Col = texture2D(sucai0,uv);
    oriCol.rgb=mix(oriCol.rgb,blendSoftLight(oriCol.rgb,sucai0Col.rgb),sucai0Ins);
    // vec3 edgeCol=texture2D(edgeColLine,vec2(edgeColOffset,0.5)).rgb;


    vec4 outCol = mix(vec4(0.0),vec4(0,0,0,0.6),oriMask.b*shadowIns);
    vec4 sucai1Col = texture2D(sucai1,uv);
    // gl_FragColor = vec4(step(0.9,orimatting),step(0.9,upMattingCol.r),0.0,1.0);
    // float flag = step(0.9,orimatting)+step(0.9,upMattingCol.r);
    vec4 resuleCol = mix(outCol,oriCol*oriMask.r,oriMask.r);
    resuleCol = mix(resuleCol,sucai1Col,oriMask.g);
    // resuleCol.a= step(0.5,flag);
    gl_FragColor = vec4(resuleCol);
    // gl_FragColor = vec4(0.0);
}
