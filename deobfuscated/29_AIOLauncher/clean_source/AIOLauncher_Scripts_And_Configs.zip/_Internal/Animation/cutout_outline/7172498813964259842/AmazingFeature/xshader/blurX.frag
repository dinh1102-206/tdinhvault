precision highp float;

uniform sampler2D inputImageTexture;
uniform sampler2D mattingmask;

varying vec2 uv;

uniform int inputWidth;
uniform int inputHeight;
uniform vec4 u_ScreenParams;
uniform float iTime;
uniform float lineSize;


void main()
{
    vec2 mySize = u_ScreenParams.xy/min(u_ScreenParams.x,u_ScreenParams.y)*720.;
    vec2 offset = vec2(0.0,1.0)/mySize;

    vec2 myuv = vec2(uv.x,uv.y);
    vec4 oriCol = texture2D(mattingmask,myuv);
    float half_gaussian_weight[9];
    
    half_gaussian_weight[0]= 0.20;//0.137401;
    half_gaussian_weight[1]= 0.19;//0.125794;
    half_gaussian_weight[2]= 0.17;//0.106483;
    half_gaussian_weight[3]= 0.15;//0.080657;
    half_gaussian_weight[4]= 0.13;//0.054670;
    half_gaussian_weight[5]= 0.11;//0.033159;
    half_gaussian_weight[6]= 0.08;//0.017997;
    half_gaussian_weight[7]= 0.05;//0.008741;
    half_gaussian_weight[8]= 0.02;//0.003799;
    float mask = oriCol.b*half_gaussian_weight[0];
    float num = half_gaussian_weight[0];
    for(int i=1;i<7;i++){
        float j = float(i);
        mask+= texture2D(mattingmask,myuv+j*lineSize*offset).b*half_gaussian_weight[i];
        mask+= texture2D(mattingmask,myuv-j*lineSize*offset).b*half_gaussian_weight[i];
        num+=2.0*half_gaussian_weight[i];
        
    }
    mask/=num;
    oriCol.b = mask;

    vec2 mask01 = oriCol.rg*half_gaussian_weight[0];
    num = half_gaussian_weight[0];
    for(int i=1;i<4;i++){
        float j = float(i);
        mask01+= texture2D(mattingmask,myuv+0.1*j*offset).rg*half_gaussian_weight[i];
        mask01+= texture2D(mattingmask,myuv-0.1*j*offset).rg*half_gaussian_weight[i];
        num+=2.0*half_gaussian_weight[i];          
    }
    mask01/=num;
    oriCol.rg = mask01;
    gl_FragColor = vec4(oriCol);
}
