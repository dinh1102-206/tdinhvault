precision highp float;

uniform sampler2D oriTex;
uniform sampler2D mattingmask;
uniform sampler2D userTex;

varying vec2 uv;



void main()
{
    vec4 oriCol = texture2D(oriTex,uv);
    vec4 userCol = texture2D(userTex,uv);
    userCol.rgb = clamp(userCol.rgb/userCol.a,0.,1.);
    oriCol.rgb = mix(oriCol.rgb,userCol.rgb,userCol.a);
    float oriMatting = texture2D(mattingmask,uv).r;
    // vec3 result = oriCol.rgb*1.5;
    // vec3 result = mix(oriCol.rgb*2.5,vec3(oriMatting),step(uv.x,0.5));
    // vec3 result = vec3(oriMatting);
    gl_FragColor = vec4(oriCol.rgb,oriMatting);
}
