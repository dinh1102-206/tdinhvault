precision highp float;

uniform sampler2D inputImageTexture;
uniform sampler2D mattingmask;

varying vec2 uv;

uniform int inputWidth;
uniform int inputHeight;
uniform vec4 u_ScreenParams;
uniform float iTime;
uniform float lineSize;
uniform float sizeFlag;

vec2 hash22(vec2 p){
    vec2 p2 = fract(p*1324.);
    p2+=dot(p2,p2.yx+22.22);
    return fract((p2.xy+p2.yx)*p2.xy)-0.5;
}
float n21(vec2 p,float seed){
    // p.x *= u_ScreenParams.x/u_ScreenParams.y;
    vec2 p3 = fract(p.yx*23.512);
    p3+=dot(p3,p3.yx+15.412+seed);
    return fract((p3.x+p3.y)*p3.x);
}
float noise(vec2 uv,float seed){
    vec2 lv=fract(uv);
     lv=lv*lv*(3.-2.*lv);//lv=smoothstep(0.,1.,lv);
    //lv=pow(lv,vec2(0.5));
    vec2 id=floor(uv);
    
    float bl=n21(id,seed);
    float br=n21(id+vec2(1,0),seed);
    float b=mix(bl,br,lv.x);
    float tl=n21(id+vec2(0,1),seed);
    float tr=n21(id+vec2(1,1),seed);
    float t=mix(tl,tr,lv.x);
    return mix(b,t,lv.y);
}
void main()
{
    vec2 ratio_offset = mix(vec2(1.0,u_ScreenParams.x/u_ScreenParams.y),vec2(u_ScreenParams.y/u_ScreenParams.x,1.0),1.0-step(u_ScreenParams.x,u_ScreenParams.y));
    
    float noiseSize = 3.5;
    vec2 noiseUV = uv;
    if(u_ScreenParams.x<u_ScreenParams.y)
        noiseUV.x*=u_ScreenParams.x/u_ScreenParams.y;
    else
        noiseUV.y*=u_ScreenParams.y/u_ScreenParams.x;
    vec2 mynoise = mix(0.05,0.08,sizeFlag)*(vec2(noise(noiseUV*noiseSize,12.43),noise(uv*noiseSize,12.11))-0.5)*ratio_offset;

    vec2 mySize = u_ScreenParams.xy/min(u_ScreenParams.x,u_ScreenParams.y)*720.;
    vec2 offset = vec2(1.0,0.0)*vec2(lineSize)/mySize;

    vec2 myuv = vec2(uv.x,uv.y)+mynoise;
    float half_gaussian_weight[9];
    
    half_gaussian_weight[0]= 0.20;//0.137401;
    half_gaussian_weight[1]= 0.19;//0.125794;
    half_gaussian_weight[2]= 0.17;//0.106483;
    half_gaussian_weight[3]= 0.15;//0.080657;
    half_gaussian_weight[4]= 0.13;//0.054670;
    half_gaussian_weight[5]= 0.11;//0.033159;
    half_gaussian_weight[6]= 0.08;//0.017997;
    half_gaussian_weight[7]= 0.05;//0.008741;
    half_gaussian_weight[8]= 0.02;//0.003799;
    float mask = texture2D(mattingmask,myuv).r*half_gaussian_weight[0];
    float num = half_gaussian_weight[0];
    for(int i=1;i<7;i++){
        float j = float(i);
        mask = max(texture2D(mattingmask,myuv+j*offset).r,mask);
        mask = max(texture2D(mattingmask,myuv-j*offset).r,mask);
    }
    // mask/=num;
    // upmask/=7.0;
    float line = mask;
    gl_FragColor = vec4(line,0.0,0.0,1.0);
}
