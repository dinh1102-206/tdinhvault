precision highp float;

uniform sampler2D orimattingMask;
uniform sampler2D mattingmask;
uniform float ins1;
uniform float ins2;
varying vec2 uv;


uniform vec4 u_ScreenParams;
mat2 rot(float angle){
    float c = cos(angle);
    float s = sin(angle);
    return mat2(c,-s,s,c);
}
vec2 hash22(vec2 p){
    vec2 p2 = fract(p*1324.);
    p2+=dot(p2,p2.yx+22.22);
    return fract((p2.xy+p2.yx)*p2.xy)-0.5;
}
float n21(vec2 p,float seed){
    // p.x *= u_ScreenParams.x/u_ScreenParams.y;
    vec2 p3 = fract(p.yx*23.512);
    p3+=dot(p3,p3.yx+15.412+seed);
    float result = fract((p3.x+p3.y)*p3.x);
    if (result<0.5)
    result-=0.05;
    else
    result+=0.05;
    return result;
}
float noise(vec2 uv,float seed){
    vec2 lv=fract(uv);
     //lv=lv*lv*(3.-2.*lv);//lv=smoothstep(0.,1.,lv);
    // lv=pow(lv,vec2(0.5));
    vec2 id=floor(uv);
    
    float bl=n21(id,seed);
    float br=n21(id+vec2(1,0),seed);
    float b=mix(bl,br,lv.x);
    float tl=n21(id+vec2(0,1),seed);
    float tr=n21(id+vec2(1,1),seed);
    float t=mix(tl,tr,lv.x);
    return mix(b,t,lv.y);
}
float fbs_noise_in(vec2 uv,float seed){
    float result= 0.7*noise(uv,seed+11.23)+
    0.5*noise(uv*2.0,seed+29.98)
    +0.3*noise(uv*5.0,seed+12.13);
    
    return result;
}
float fbs_noise_out(vec2 uv,float seed){
    float result= 0.7*noise(uv,seed+12.14)+
    0.5*noise(uv*2.0,seed+22.23)
    +0.3*noise(uv*5.0,seed+11.15);
    return result;
}
void main()
{
    vec2 offset = mix(vec2(1.0,u_ScreenParams.x/u_ScreenParams.y),vec2(u_ScreenParams.y/u_ScreenParams.x,1.0),1.0-step(u_ScreenParams.x,u_ScreenParams.y));
    
    float noiseSize = 20.;
    vec2 mynoise = 0.012*ins1*(vec2(fbs_noise_in(uv*noiseSize,12.32),fbs_noise_in(uv*noiseSize,11.24))-0.5)*offset
    +0.003*ins2*hash22(uv)*offset;
    float orimatting = texture2D(orimattingMask,vec2(uv.x,uv.y)+mynoise).r;
    
    vec2 mynoise2 = 0.012*ins1*(vec2(fbs_noise_out(uv*noiseSize*rot(1.2),11.94),fbs_noise_out(uv*noiseSize*rot(1.2),13.52))-0.5)*offset
    +0.004*ins2*hash22(uv)*offset;

    vec4 upMattingCol = texture2D(mattingmask,uv+mynoise2);
    // // float upMatting = upMattingCol.r;

    // vec4 oriCol = texture2D(oriTex,uv);

    // vec3 edgeCol=texture2D(edgeColLine,vec2(edgeColOffset,0.5)).rgb;


    // vec4 sucai0Col = texture2D(sucai0,uv);
    // sucai0Col.rgb*=edgeCol;
    // vec4 sucai1Col = texture2D(sucai1,uv);
    // gl_FragColor = vec4(step(0.9,orimatting),step(0.9,upMattingCol.r),0.0,1.0);
    float flag = step(0.9,orimatting)+step(0.9,upMattingCol.r);
    // vec4 resuleCol = mix(sucai0Col,oriCol,step(1.5,flag));
    // resuleCol = mix(resuleCol,sucai1Col,step(0.5,flag)*step(flag,1.5));
    // resuleCol.a= step(0.5,flag);
    gl_FragColor = vec4(step(1.5,flag),step(0.5,flag)*step(flag,1.5),step(0.5,flag),1.0);
    

}
