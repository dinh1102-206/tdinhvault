precision highp float;

uniform sampler2D orimattingMask;
uniform sampler2D outMatting0;
uniform sampler2D outMatting1;
uniform sampler2D oriTex;
uniform float sizeFlag;

varying vec2 uv;


uniform vec4 u_ScreenParams;
uniform float edgeColOffset;
uniform sampler2D edgeColLine;
uniform float alpha;
uniform float lightIns;
uniform float R;
uniform float G;
uniform float B;

void main()
{
    float orimatting = texture2D(orimattingMask,vec2(uv.x,1.0-uv.y)).r;

    
    // vec4 oriCol = texture2D(oriTex,vec2(uv.x,1.0-uv.y));
    // oriCol.rgb = clamp(oriCol.rgb/oriCol.a,0.0,1.0);

    // vec4 myResultCol = vec3(R,G,B);

    vec3 edgeCol0=vec3(R,G,B);
    vec4 upMattingCol0 = texture2D(outMatting0,vec2(uv.x,1.0-uv.y));
    float upMatting0 = upMattingCol0.r;
    float downIns0 = 0.05;
    // upMatting0 = smoothstep(0.0,1.0,upMatting0);

    //vec3 edgeCol1=texture2D(edgeColLine,vec2(edgeColOffset,0.5)).rgb;
    vec3 edgeCol1=vec3(R,G,B);
    vec4 upMattingCol1 = texture2D(outMatting1,vec2(uv.x,1.0-uv.y));
    float upMatting1 = upMattingCol1.r;
    float downIns1 = 0.05;

    // myResultCol.rgb = mix(myResultCol.rgb,edgeCol1.rgb,1.0-orimatting);
   

    float lastAlpha = clamp(clamp(upMatting0*lightIns*1.5+upMatting1*0.5*(lightIns*0.5+0.5),0.0,1.0)-orimatting,0.0,1.0);
    gl_FragColor = vec4(edgeCol1*lastAlpha,lastAlpha);
    // gl_FragColor = vec4(upMatting1);

    

}
