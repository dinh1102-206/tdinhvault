precision highp float;

attribute vec3 attPosition;
attribute vec2 attUV;
uniform mat4 u_MVP;
varying vec2 uv;
uniform vec4 u_ScreenParams;
void main() {
    gl_Position = vec4(attPosition,1.0);
    uv = vec2(attUV.x,1.0-attUV.y);

}
