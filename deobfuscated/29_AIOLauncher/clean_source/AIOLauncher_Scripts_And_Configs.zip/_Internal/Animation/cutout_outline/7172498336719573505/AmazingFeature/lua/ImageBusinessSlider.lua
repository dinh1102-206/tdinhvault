--write by editor  EffectSDK:10.9.0 EngineVersion:10.68.0 EditorBuildTime:Apr_26_2022_04_38_07
--sliderVersion: 20210901  Lua generation date: Wed Dec  7 16:03:12 2022


local exports = exports or {}
local ImageBusinessSlider = ImageBusinessSlider or {}
ImageBusinessSlider.__index = ImageBusinessSlider


function ImageBusinessSlider.new(construct, ...)
    local self = setmetatable({}, ImageBusinessSlider)
    if construct and ImageBusinessSlider.constructor then
        ImageBusinessSlider.constructor(self, ...)
    end
    return self
end


local function remap(x, a, b)
    return x * (b - a) + a
end


function ImageBusinessSlider:onStart(sys)
    self.blur6Material0 = sys.scene:findEntityBy("blur6"):getComponent("Renderer").material
    self.blur7Material1 = sys.scene:findEntityBy("blur7"):getComponent("Renderer").material
    self.blur1Material2 = sys.scene:findEntityBy("blur1"):getComponent("Renderer").material
    self.blur5Material3 = sys.scene:findEntityBy("blur5"):getComponent("Renderer").material
    self.blur2Material4 = sys.scene:findEntityBy("blur2"):getComponent("Renderer").material
    self.Pass2Material5 = sys.scene:findEntityBy("Pass2"):getComponent("Renderer").material
    self.blur3Material6 = sys.scene:findEntityBy("blur3"):getComponent("Renderer").material
    self.blur0Material7 = sys.scene:findEntityBy("blur0"):getComponent("Renderer").material
    self.blur4Material8 = sys.scene:findEntityBy("blur4"):getComponent("Renderer").material
end


function ImageBusinessSlider:onEvent(sys,event)
    if event.args:get(0) == "effects_adjust_size" then
        local intensity = event.args:get(1)
        self.blur6Material0["lineSize"] = remap(intensity,0.75,7.5)
        self.blur7Material1["lineSize"] = remap(intensity,0.75,7.5)
        self.blur1Material2["lineSize"] = remap(intensity,0.75,7.5)
        self.blur5Material3["lineSize"] = remap(intensity,0.75,7.5)
        self.blur2Material4["lineSize"] = remap(intensity,0.75,7.5)
        self.Pass2Material5["sizeFlag"] = remap(intensity,0,1)
        self.blur3Material6["lineSize"] = remap(intensity,0.75,7.5)
        self.blur0Material7["lineSize"] = remap(intensity,0.75,7.5)
        self.blur4Material8["sizeFlag"] = remap(intensity,0,1)
        self.blur4Material8["lineSize"] = remap(intensity,0,1)
    end
    if event.args:get(0) == "effects_adjust_alpha" then
        local intensity = event.args:get(1)
        self.Pass2Material5["lightIns"] = remap(intensity,0.4,0.9)
    end
    -- if event.args:get(0) == "effects_adjust_alpha" then
    --     local intensity = event.args:get(1)
    --     self.Pass2Material5["alpha"] = remap(intensity,0.3,1)
    -- end
    -- if event.args:get(0) == "effects_adjust_color" then
    --     local intensity = event.args:get(1)
    --     self.Pass2Material5["edgeColOffset"] = remap(intensity,0,1)
    -- end
end


exports.ImageBusinessSlider = ImageBusinessSlider
return exports