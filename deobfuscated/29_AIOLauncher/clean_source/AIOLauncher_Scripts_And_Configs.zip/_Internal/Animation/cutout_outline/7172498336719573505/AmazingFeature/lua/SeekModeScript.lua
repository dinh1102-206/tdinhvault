--@input float curTime = 0.0{"widget":"slider","min":0,"max":10}

local exports = exports or {}
local SeekModeScript = SeekModeScript or {}
SeekModeScript.__index = SeekModeScript

function SeekModeScript.new(construct, ...)
    local self = setmetatable({}, SeekModeScript)
    if construct and SeekModeScript.constructor then SeekModeScript.constructor(self, ...) end
    self.startTime = 0.0
    self.endTime = 10.0  
    self.curTime = 0.0
    self.width = 0
    self.height = 0
    self.lastfpsNum = -1
    self.speed = 1.0
    
    return self
end

function SeekModeScript:onStart(comp)

    self.tableCom = comp.entity.scene:findEntityBy("Table"):getComponent("TableComponent").table

    self.props    = comp.entity:getComponent("ScriptComponent").properties
    
    self.blur0mat = comp.entity.scene:findEntityBy("blur0"):getComponent("MeshRenderer").material
    
    self.blur1mat = comp.entity.scene:findEntityBy("blur1"):getComponent("MeshRenderer").material
    self.pass2mat = comp.entity.scene:findEntityBy("Pass2"):getComponent("MeshRenderer").material
    
    self.myMatting = Amaz.Texture2D()
    self.blur0mat:setTex("mattingmask", self.myMatting)
    self.pass2mat:setTex("orimattingMask", self.myMatting)
    
    -- self.grabCam = comp.entity.scene:findEntityBy("grabCam")
    -- self.grabCam2 = comp.entity.scene:findEntityBy("grabAlphaCam")
    --"Transform"、"AnimSeqComponent"
end

function SeekModeScript:onUpdate(comp, detalTime)
    self.curTime=self.curTime+detalTime
    self:seekToTime(comp, (self.curTime - self.startTime)*self.speed)
end

function SeekModeScript:seekToTime(comp, time)
    -- local fps = 3
    -- local fpsNum  = math.floor(fps*time)
    -- self.grabCam.visible = false
    -- self.grabCam2.visible = false
    -- if(self.lastfpsNum~=fpsNum) then
    --     self.lastfpsNum = fpsNum
    --     self.blur0mat:setFloat("iTime", time*3)
    --     self.pass2mat:setFloat("iTime", time*3)
    --     self.pass2mat:setFloat("fpsNum", fpsNum)
    --     self.grabCam.visible = true
    --     self.grabCam2.visible = true
    -- end
    -- local w = Amaz.BuiltinObject:getInputTextureWidth()
    -- local h = Amaz.BuiltinObject:getInputTextureHeight()
    -- if(self.width~= w or self.height~=h) then
    --     self.width = w
    --     self.height=h
    --     self.grabCam.visible = true
    --     self.grabCam2.visible = true
    -- end
    
    -- Amaz.Algorithm.setAlgorithmParamInt("", "face_0", "face_max_num", faceNumber)
end

function SeekModeScript:onEvent(sys,event)
    -- if event.args:get(0) == "effects_adjust_speed" then
    --     local intensity = event.args:get(1)
    --     self.speed = 1.5*intensity+0.5
    -- end
    if event.args:get(0) == "segMask"  then
        local bgMask = event.args:get(1)
        if(bgMask == nil) then
            Amaz.LOGI("YMLog","not nil")
        else
            Amaz.LOGI("YMLog","nil")
        end
        self.blur0mat:getTex("mattingmask"):storage(bgMask)
        self.pass2mat:getTex("orimattingMask"):storage(bgMask)
    end
    if event.args:get(0) == "matting_stroke_adjust_color"  then
        local lineCol = event.args:get(1)
        self.pass2mat:setFloat("R",lineCol:get(1))
        self.pass2mat:setFloat("G",lineCol:get(2))
        self.pass2mat:setFloat("B",lineCol:get(3))
    end
end

exports.SeekModeScript = SeekModeScript
return exports






