const Amaz = effect.Amaz;
const cv = Amaz.JSWrapCV;
const SCRIPT_NAME = 'GameController';
/**
 * System script is NOT recommended to be used anymore.
 * Avoid using system script unless you really have to.
 */
class GameController {
    constructor() {
        this.name = SCRIPT_NAME;
        this.ins = 1
        this.dis = 7
        this.ins2 = 0.95
    }

    /** onInit is called before onStart(). */
    onInit() {}

    /** onStart is called before the first onUpdate() call. */
    onStart() {
        // this.greaterBtnMat = Amaz.AmazingUtil.guidToPointer(new Amaz.Guid("11406183970291428187", "391554069649860755"))
        // this.lessBtnMat = Amaz.AmazingUtil.guidToPointer(new Amaz.Guid("15730492639021703853", "5769520455220162741"))
        this.dataTable = this.scene.findEntityBy("table").getComponent("TableComponent").table
    }

    jsArrayToAmzVec(contours) {
            let result = new Amaz.Vector();
            for (let index = 0; index < contours.length; index++) {
                let contour = contours[index];
                let vec2Vec = new Amaz.Vec2Vector();
                Amaz.AmazingUtil.arrayBufferToPrimitiveVector(contour, vec2Vec);
                result.pushBack(vec2Vec)
            }
            return result
                // return contours.map(contour => {
                //     let vec2Vec = new Amaz.Vec2Vector();
                //     let viewArray = new Float32Array(contour);
                //     for (let index = 0; index < viewArray.length;) {
                //         let vec2f = new Amaz.Vector2f;
                //         let element = viewArray[index++];
                //         vec2f.x = element
                //         element = viewArray[index++];
                //         vec2f.y = element
                //     }
                //     // .forEach(element => {
                //     //     let vec2f = new Amaz.Vector2f;
                //     //     vec2f.x = element[0];
                //     //     vec2f.y = element[1];
                //     //     vec2Vec.pushBack(vec2f);
                //     // });
                //     return vec2Vec;
                // });
        }
        /** onUpdate is called once every frame. */
    onUpdate(deltaTime) {
        let bgMask = this.bgMask;
        let algo = Amaz.AmazingManager.getSingleton('Algorithm').getAEAlgorithmResult();
        let mattingInfo = algo.getBgInfo();
        if (mattingInfo) {
            bgMask = mattingInfo.bgMask;
        }
        let mat = cv.Mat(bgMask);
        let mat_buf = cv.Mat()
        let min_w_h = Math.min(mat.cols,mat.rows)
        let scale = this.ins2*this.ins*168/min_w_h
        cv.resize(mat,mat,[mat.cols*scale,mat.rows*scale])
        // let matbuf = cv.Mat(rgb.rows + 8*2, rgb.cols + 8*2, rgb.depth());
        cv.copyMakeBorder(mat, mat_buf, 28, 28, 28, 28, 0,[0]);
        
        //newmat = cv.copyMakeBorder(mat, 8, 8, 8, 8, cv.BORDER_ConSTANT, None, [0,0,0])
        let elem = cv.getStructuringElement(2, [this.dis, this.dis]);
        // cv.dilate(mat, mat, elem);
        // let newBgMask = mat.toImage(Amaz.PixelFormat.L8Unorm)

        cv.dilate(mat_buf, mat_buf, elem);
        let elem2 = cv.getStructuringElement(1, [4, 4]);
        // cv.dilate(mat, mat, elem);
        // let newBgMask = mat.toImage(Amaz.PixelFormat.L8Unorm)

        cv.dilate(mat_buf, mat_buf, elem2);
        this.mat = mat;
        let newBgMask = this.mat.toImage(Amaz.PixelFormat.L8Unorm)

        let contours = new Array();
        cv.findContours(mat_buf, contours, 0, 1);
        let vec2vec = this.jsArrayToAmzVec(contours);
        this.dataTable.set("contours", vec2vec)
        this.dataTable.set("image_Height", mat.rows+56)
        this.dataTable.set("image_Width", mat.cols+56)
        this.dataTable.set("mask", newBgMask)
    }

    /** onLateUpdate is called once every frame after onUpdate(). */
    onLateUpdate(deltaTime) {}

    /** onEvent is called when an event arrives. */
    onEvent(event) {
            if (event.args.get(0) == 'segMask') {
                this.bgMask = event.args.get(1)
            }
            if (event.args.get(0) == 'effects_adjust_size') {
                this.ins = (0.48-0.3*event.args.get(1))*1.5+0.5
            }
            if (event.args.get(0) == 'effects_adjust_distance') {
                this.dis = 3+15*event.args.get(1)
            }
        }
        /** onDestroy is called when this script instance is destroyed. */
    onDestroy() {}

}

exports.GameController = GameController;