--write by editor  EffectSDK:12.7.0 EngineVersion:12.7.0 EditorBuildTime:Nov__7_2022_11_34_02
--sliderVersion: 20210901  Lua generation date: Tue Nov 29 17:14:34 2022


local exports = exports or {}
local ImageBusinessSlider = ImageBusinessSlider or {}
ImageBusinessSlider.__index = ImageBusinessSlider


function ImageBusinessSlider.new(construct, ...)
    local self = setmetatable({}, ImageBusinessSlider)
    if construct and ImageBusinessSlider.constructor then
        ImageBusinessSlider.constructor(self, ...)
    end
    return self
end


local function remap(x, a, b)
    return x * (b - a) + a
end


function ImageBusinessSlider:onStart(sys)
    self.resultMaterial0 = sys.scene:findEntityBy("result"):getComponent("Renderer").material
    self.SeekModeScriptMaterial1 = sys.scene:findEntityBy("SeekModeScript"):getComponent("Renderer").material
end


function ImageBusinessSlider:onEvent(sys,event)
    if event.args:get(0) == "matting_stroke_adjust_color"  then
        local lineCol = event.args:get(1)
        self.resultMaterial0:setFloat("R",lineCol:get(1))
        self.resultMaterial0:setFloat("G",lineCol:get(2))
        self.resultMaterial0:setFloat("B",lineCol:get(3))
    end
    if event.args:get(0) == "effects_adjust_size" then
        local intensity = event.args:get(1)
        self.SeekModeScriptMaterial1["size"] = remap(intensity,0.18,0.5)
        -- self.SeekModeScriptMaterial1["lineLength"] = remap(intensity,0.2,1)
        -- self.SeekModeScriptMaterial1["lineDis"] = remap(intensity,0.2,1)
    end
end


exports.ImageBusinessSlider = ImageBusinessSlider
return exports