precision highp float;

// attribute vec4 color;
attribute vec3 position;
attribute vec2 texcoord0;
// varying vec2 fTexCoord;
varying vec4 screenPos;
uniform float entityNum; 
varying float circleSize;
varying vec2 oriUV;
varying float noiseFlag;
varying vec2 sucaiUV;
varying vec2 sucaiUV2;
// uniform float lineDis;
// uniform float lineLength;


mat2 rotmat2(float id){
    float id1 = fract(id*1.123);
    id1+=dot(id1,id1+2.225);
    float idRand = fract((id1+id1)*id1)*6.28;
    // float dxy=1./length(vec2(dx,dy));
    float cosA=cos(idRand);
    float sinA=sin(idRand);
    return mat2(cosA,-sinA,
                sinA,cosA);
}
mat2 rot2mat2(float id){
    float id1 = fract(id*1.145);
    id1+=dot(id1,id1+2.258);
    float idRand = fract((id1+id1)*id1)*6.28;
    // float dxy=1./length(vec2(dx,dy));
    float cosA=cos(idRand);
    float sinA=sin(idRand);
    return mat2(cosA,-sinA,
                sinA,cosA);
}
float hash11(float p){
    float p1 = fract(p*1.123);
    p1+=dot(p1,p1+2.225);
    return fract((p1+p1)*p1);
}
float mynoise(float id,float num)
{
    float ID = floor(id/num);
    float temp = (id-ID*num)/num;
    float result = mix(hash11(ID),hash11(ID+1.0),temp);
    // result = 1.0;
    if((ID+1.0)*num>entityNum){
        temp = (id-ID*num)/(entityNum-ID*num);
        result = mix(hash11(ID),hash11(0.),temp);
        // result=0.0;
    }
    return result;
}
void main()
{
    // fTexCoord.x = (abs(mod(position.z,100.0))+texcoord0.x)*0.01;
    
    // fTexCoord.y  =1.0-texcoord0.y;
    oriUV = texcoord0;
    // vec4 mycol = color;
    // float Xdis=(color.z-0.2)*10.;
    // float Ydis=(color.w-0.2)*10.;
    // screenPos=vec4(rot2(position.xy,color.xy,Xdis,Ydis,ratio),0.0,1.0);
    screenPos=vec4(position.xy,0.0,1.0);
    circleSize = mynoise(position.z,20.)*0.2+0.8;
    noiseFlag = 1.0;
    sucaiUV = (oriUV-0.5)*rotmat2(position.z)+0.5;
    sucaiUV2 = (oriUV-0.5)*rot2mat2(position.z)+0.5;
    // float flag = step(mod(id,lineDis+lineLength),lineLength);
    // screenPos = mix(vec4(-2.,-2.,0.0,1.0),screenPos,flag);
    gl_Position = screenPos;
}
