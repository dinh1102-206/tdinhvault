precision highp float;

varying vec2 uv;
uniform sampler2D inputImageTexture;
uniform sampler2D oriTex;
uniform sampler2D lineColTex;
uniform float colIns;
uniform vec4 u_ScreenParams;
uniform float R;
uniform float G;
uniform float B;
#define textureCoordinate uv
float n21(vec2 p,float seed){
    // p.x *= u_ScreenParams.x/u_ScreenParams.y;
    vec2 p3 = fract(p.yx*23.512);
    p3+=dot(p3,p3.yx+15.412+seed);
    float result = fract((p3.x+p3.y)*p3.x);
    if (result<0.5)
    result-=0.05;
    else
    result+=0.05;
    return result;
}
float noise(vec2 uv,float seed){
    vec2 lv=fract(uv);
     lv=lv*lv*(3.-2.*lv);//lv=smoothstep(0.,1.,lv);
    // lv=pow(lv,vec2(0.5));
    vec2 id=floor(uv);
    
    float bl=n21(id,seed);
    float br=n21(id+vec2(1,0),seed);
    float b=mix(bl,br,lv.x);
    float tl=n21(id+vec2(0,1),seed);
    float tr=n21(id+vec2(1,1),seed);
    float t=mix(tl,tr,lv.x);
    return mix(b,t,lv.y);
}
void main()
{
     vec2 offset = mix(vec2(1.0,u_ScreenParams.x/u_ScreenParams.y),vec2(u_ScreenParams.y/u_ScreenParams.x,1.0),1.0-step(u_ScreenParams.x,u_ScreenParams.y));
    float noiseSize = 5.;
    // vec2 noise = 0.04*(vec2(noise(uv*noiseSize,12.32),noise(uv*noiseSize,11.24))-0.5)*offset;
    // float noiseIns = smoothstep(0.0,0.05,uv.x)*smoothstep(0.0,0.05,1.0-uv.x)
    // *smoothstep(0.0,0.05,uv.y)*smoothstep(0.0,0.05,1.0-uv.y);
    float mask = texture2D(inputImageTexture,vec2(uv.x,1.0-uv.y)).r;
    vec4 oriCol = texture2D(oriTex,textureCoordinate);
    oriCol.rgb =mix(oriCol.rgb,vec3(R,G,B),mask); 
    oriCol.a+=mask;
    oriCol.a = clamp(oriCol.a,0.0,1.0);
    gl_FragColor = oriCol;
}
