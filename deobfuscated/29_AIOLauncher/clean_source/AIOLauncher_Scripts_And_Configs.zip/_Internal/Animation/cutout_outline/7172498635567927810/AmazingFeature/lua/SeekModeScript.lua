local exports = exports or {}
local SeekModeScript = SeekModeScript or {}

SeekModeScript.__index = SeekModeScript
function SeekModeScript.new(construct, ...)
    local self = setmetatable({}, SeekModeScript)
    if construct and SeekModeScript.constructor then
        SeekModeScript.constructor(self, ...)
    end
    self.startTime = 0.0
    self.endTime = 3.0
    self.curTime = 0.0
    self.width = 0
    self.height = 0
    self.entityNum = 200
    self.oriSize = 0.10
    self.size = 0.1
    self.ratio = 0
    self.speed = 50
    self.lineLength = 10
    self.lineDis = 10
    self.flag = 1
    self.lastflag = 0
    return self
end

function SeekModeScript:createCustomMesh()
    local customMesh = Amaz.Mesh()
    local customSubMesh = Amaz.SubMesh()
    customSubMesh.primitive = Amaz.Primitive.TRIANGLES
    if customMesh and customSubMesh then
    end

    local pos = Amaz.VertexAttribDesc()
    pos.semantic = Amaz.VertexAttribType.POSITION

    local uv = Amaz.VertexAttribDesc()
    uv.semantic = Amaz.VertexAttribType.TEXCOORD0

    -- local color = Amaz.VertexAttribDesc()
    -- color.semantic = Amaz.VertexAttribType.COLOR

    local vads = Amaz.Vector()
    -- vads:pushBack(color)
    vads:pushBack(pos)
    vads:pushBack(uv)

    customMesh.vertexAttribs = vads

    local vertexData = {}
    local indexData = {}

    local fv = Amaz.FloatVector()

    local indices = Amaz.UInt16Vector()
    local result = self.dataTable:get("contours")
    local pointNum = 1
    if result then
        local findContourCount = result:size()
        if findContourCount ~= 0 then
            local width = self.dataTable:get("image_Width")
            local height = self.dataTable:get("image_Height")
            -- local findContourInfo = result:get(0)
            local contoursSize = result:size() - 1
            
            local maxIndex = 0
            local maxNum = 0
            for p=0 ,contoursSize do
                local tempContours = result:get(p)
                local tempNum = tempContours:size() - 1
                if tempNum>maxNum then
                    maxNum=tempNum
                    maxIndex=p
                end
            end
            
            local contours = result:get(maxIndex)
            local num = contours:size() - 1
            self.entityNum = num
            local dis = 2.0
            -- local delta = num / 40
            local tempSpeed = 0.0
            local front = math.floor(self.curTime * tempSpeed - 0 * dis + num * (1.6))
            local numX = 0
            local numY = 0
            for i = -3, 3 do
                local temp = contours:get(math.mod(front + i*dis, num))
                numX = numX + temp.x
                numY = numY + temp.y
            end
            local scaleX = (width)/ (width-56)
            local scaleY = (height)/ (height-56)
            for i = 1, num,dis do
                if (1) then
                    local tempFront =
                        contours:get(
                        math.mod(math.floor(self.curTime * tempSpeed - (i + 3*dis) * 1 + num * (1.6)), num)
                    )
                    local tempLast =
                        contours:get(
                        math.mod(math.floor(self.curTime * tempSpeed - (i - 4*dis) * 1 + num * (1.6)), num)
                    )
                    numX = numX + tempFront.x - tempLast.x
                    numY = numY + tempFront.y - tempLast.y
                    -- local 
                    local sucaipoint = Amaz.Vector2f(numX / 7+0.5, numY / 7+0.5)
                    -- sucaipoint = contours:get(
                    --     math.mod(math.floor(self.curTime * tempSpeed - (i + 3) * dis + num * (1.6)), num)
                    -- )
                    local sucaipointX = (sucaipoint.x / width - 0.5) * 2 * scaleX
                    local sucaipointY = (1.0 - sucaipoint.y / height - 0.5) * 2 * scaleY
                    self.flag = 1.0
                   
                    for vertexIndex = 1, 4 do
                        local uv = {}
                        local width = 1.0
                        if vertexIndex == 1 then
                            uv.x = 0
                            uv.y = width
                        elseif vertexIndex == 2 then
                            uv.x = width
                            uv.y = width
                        elseif vertexIndex == 3 then
                            uv.x = width
                            uv.y = 0
                        else
                            uv.x = 0
                            uv.y = 0
                        end
                        local point = {}
                        point[1] = sucaipointX + (uv.x - 0.5) * self.size
                        point[2] = sucaipointY + (uv.y - 0.5) * self.size * self.ratio
                        -- fv:pushBack(sucaipointX)
                        -- fv:pushBack(sucaipointY)
                        -- fv:pushBack(Xdis)
                        -- fv:pushBack(Ydis)

                        fv:pushBack(point[1])
                        fv:pushBack(point[2])
                        fv:pushBack(pointNum - 1)
                        fv:pushBack(uv.x)
                        fv:pushBack(uv.y)
                    end
                    local index = (pointNum - 1) * 4

                    indices:pushBack(0 + index)
                    indices:pushBack(1 + index)
                    indices:pushBack(3 + index)
                    indices:pushBack(1 + index)
                    indices:pushBack(2 + index)
                    indices:pushBack(3 + index)
                    pointNum = pointNum+1
                end
            end
            
        else
        end
    end
    customMesh.vertices = fv
    customSubMesh.indices16 = indices
    customSubMesh.mesh = customMesh
    customMesh:addSubMesh(customSubMesh)
    return customMesh
end
function SeekModeScript:onUpdate(comp, detalTime)
    self.curTime = self.curTime + detalTime
    self:seekToTime(comp, self.curTime - self.startTime)
end

function SeekModeScript:onStart(comp)
    local w = Amaz.BuiltinObject:getInputTextureWidth()
    local h = Amaz.BuiltinObject:getInputTextureHeight()
    self.ratio = w / h
    self.animSeqCom = comp.entity.scene:findEntityBy("SeekModeScript"):getComponent("AnimSeqComponent")
    self.MeshEntity = comp.entity.scene:findEntityBy("SeekModeScript"):getComponent("MeshRenderer")
    self.material = comp.entity.scene:findEntityBy("SeekModeScript"):getComponent("MeshRenderer").material
    self.material1 = comp.entity.scene:findEntityBy("blur1"):getComponent("MeshRenderer").material
    self.MeshEntity.mesh = self.customMesh
    self.dataTable = comp.entity.scene:findEntityBy("table"):getComponent("TableComponent").table
    self.customMesh = self:createCustomMesh()
    self.material:setFloat("entityNum", self.entityNum)
    self.material1:setTex("ori1Tex", Amaz.Texture2D())

end

function SeekModeScript:seekToTime(comp, time)
    -- self.animSeqCom:seekToTime(time)
    local w = Amaz.BuiltinObject:getInputTextureWidth()
    local h = Amaz.BuiltinObject:getInputTextureHeight()
    if w ~= self.width or h ~= self.height then
        self.cameraRT = comp.entity.scene:findEntityBy("Camera_entity"):getComponent("Camera").renderTexture
        self.cameraRT.width = w*720/math.min(w,h)
        self.cameraRT.height = h*720/math.min(w,h)
        self.cameraRT2 = comp.entity.scene:findEntityBy("CamBlur"):getComponent("Camera").renderTexture
        self.cameraRT2.width = w*720/math.min(w,h)
        self.cameraRT2.height = h*720/math.min(w,h)
        self.width = w
        self.height = h
        self.ratio = w / h
        self.material:setFloat("ratio", self.ratio)
    end
    local tage = 1
    if h > w then
        tage = 0.75
    end
    -- self.material:setFloat("lineLength", self.lineLength)
    -- self.material:setFloat("lineDis", self.lineDis)
    self.oriSize = (0.01 + 0.2 * self.material:getFloat("size"))
    self.size = self.oriSize / (self.ratio + 0.0001) * tage
    self.customMesh = self:createCustomMesh()
    self.MeshEntity.mesh = self.customMesh
    if self.dataTable:get("mask") then
        self.material1:getTex("ori1Tex"):storage(self.dataTable:get("mask"))
    end
    self.material:setFloat("entityNum", self.entityNum)
    -- Amaz.LOGI("asdasd",self.dataTable:get('image_Width'))
end

function SeekModeScript:onEvent(sys, event)
    -- if "effects_adjust_number" == event.args:get(0) then
    --     local intensity = event.args:get(1)
    --     self.lineLength = 5+40*intensity
    -- end
    -- if "effects_adjust_intensity" == event.args:get(0) then
    --     local intensity = event.args:get(1)
    --     self.lineDis = 10+15*intensity
    -- end
    if "effects_adjust_size" == event.args:get(0) then
        local intensity = event.args:get(1)
        self.oriSize = 0.05 + 0.2 * intensity
    end
    -- if "effects_adjust_size" == event.args:get(0) then
    --     local intensity = event.args:get(1)
    --     if(intensity<0.37) then
    --         self.oriSize=(1.5*intensity+0.9)*0.1
    --     else
    --         self.oriSize=(2.0*intensity+0.9-0.185)*0.1
    --     end
    -- end
    -- if "effects_adjust_speed" == event.args:get(0) then
    --     local intensity = event.args:get(1)
    --     self.speed=50*(1.5*intensity+0.5)
    -- end
end

exports.SeekModeScript = SeekModeScript
return exports
