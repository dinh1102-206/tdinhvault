attribute vec3 attPosition;
attribute vec2 attUV;

const int kernel_size = 5;
varying vec2 textureCoordinate;
varying float blurWeight[kernel_size];

void main() {
    gl_Position = vec4(attPosition, 1.0);
    textureCoordinate = attUV;
    blurWeight[0] = 0.02192964;
    blurWeight[1] = 0.22851215;
    blurWeight[2] = 0.49911642;
    blurWeight[3] = 0.22851215;
    blurWeight[4] = 0.02192964;
}   