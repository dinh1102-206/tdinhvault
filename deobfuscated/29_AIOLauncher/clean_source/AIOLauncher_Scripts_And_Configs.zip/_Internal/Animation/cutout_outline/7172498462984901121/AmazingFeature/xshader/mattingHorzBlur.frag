precision highp float;

uniform sampler2D mattingmask;
uniform float texelWidthOffset;
const int kernel_size = 5;
varying vec2 textureCoordinate;
varying float blurWeight[kernel_size];
uniform vec4 u_ScreenParams;

void main() {
    float sum = 0.0;
    vec2 mySize = u_ScreenParams.xy/min(u_ScreenParams.x,u_ScreenParams.y)*720.;
    for (int i = 0; i < kernel_size; i++) {
        vec2 blurCoordinate = textureCoordinate + vec2(texelWidthOffset * float(i - kernel_size / 2), 0.0)/mySize;
        sum += texture2D(mattingmask, blurCoordinate).r * blurWeight[i];
    }
    gl_FragColor = vec4(sum, 0.0, 0.0, 1.0);
}