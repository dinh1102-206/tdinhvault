precision highp float;

varying vec2 textureCoordinate;
uniform sampler2D mattingmask;

const float k = 8.0;
const float ct = 0.5;
const float pi = 3.1415926;

void main() {
    float mattingValue = texture2D(mattingmask, vec2(textureCoordinate.x,1.0-textureCoordinate.y)).r;
    if (mattingValue < - pi / (2.0 * k) + ct) {
        mattingValue = 0.0;
    } else if (mattingValue > pi / (2.0 * k) + ct) {
        mattingValue = 1.0;
    } else {
        mattingValue = 0.5 * sin(k * (mattingValue - ct)) + 0.5;
    }
    gl_FragColor = vec4(mattingValue, 0.0, 0.0, 1.0);
}