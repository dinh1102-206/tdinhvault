precision highp float;

uniform sampler2D orimattingMask;
uniform sampler2D mattingmask;
uniform sampler2D oriTex;
uniform float vIns;
uniform float hIns;
varying vec2 uv;
uniform float R;
uniform float G;
uniform float B;

uniform vec4 u_ScreenParams;
uniform float edgeColOffset;
uniform sampler2D edgeColLine;

mat2 rot(float angle){
    float s = sin(angle);
    float c = cos(angle);
    return mat2(c,-s,s,c);
}
void main()
{
    float orimatting = texture2D(orimattingMask,vec2(uv.x,uv.y)).r;

    vec2 mySize = u_ScreenParams.xy/min(u_ScreenParams.x,u_ScreenParams.y)*720.;
    vec2 offset = (vec2(-100.0*hIns,-100.0*vIns))/mySize;
    vec2 newUV = vec2(uv.x,uv.y)+offset;
    vec4 upMattingCol = texture2D(mattingmask,newUV)*step(0.0,newUV.x)*step(0.0,newUV.y)*step(newUV.x,1.0)*step(newUV.y,1.0);
    float upMatting = upMattingCol.r;
    vec4 oriCol = texture2D(oriTex,vec2(uv.x,1.0-uv.y));
    if(upMatting>0.){
    oriCol.rgb = clamp(oriCol.rgb/oriCol.a,0.0,1.0);
    }

    vec3 edgeCol=texture2D(edgeColLine,vec2(edgeColOffset,0.5)).rgb;
    edgeCol=vec3(R,G,B);

    vec4 myResultCol = oriCol;
    upMatting = upMatting;
    

    myResultCol.rgb = mix(myResultCol.rgb,edgeCol.rgb,upMatting);
    myResultCol.rgb = mix(myResultCol.rgb,oriCol.rgb,orimatting);

    float lastAlpha = clamp(oriCol.a+upMatting,0.0,1.0);
    gl_FragColor = vec4(myResultCol.rgb,lastAlpha);
    // gl_FragColor = vec4(orimatting);

    

}
