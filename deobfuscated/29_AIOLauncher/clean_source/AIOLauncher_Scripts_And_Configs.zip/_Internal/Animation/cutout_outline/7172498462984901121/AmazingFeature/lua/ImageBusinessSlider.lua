--write by editor  EffectSDK:10.5.0 EngineVersion:10.66.0 EditorBuildTime:Dec__7_2021_12_06_29
--sliderVersion: 20210901  Lua generation date: Thu Oct 27 15:21:05 2022


local exports = exports or {}
local ImageBusinessSlider = ImageBusinessSlider or {}
ImageBusinessSlider.__index = ImageBusinessSlider


function ImageBusinessSlider.new(construct, ...)
    local self = setmetatable({}, ImageBusinessSlider)
    if construct and ImageBusinessSlider.constructor then
        ImageBusinessSlider.constructor(self, ...)
    end
    return self
end


local function remap(x, a, b)
    return x * (b - a) + a
end


function ImageBusinessSlider:onStart(sys)
    self.Pass2Material0 = sys.scene:findEntityBy("Pass2"):getComponent("Renderer").material
end


function ImageBusinessSlider:onEvent(sys,event)
    if event.args:get(0) == "effects_adjust_horizontal_shift" then
        local intensity = event.args:get(1)
        self.Pass2Material0["hIns"] = remap(intensity,-1,1)
    end
    if event.args:get(0) == "effects_adjust_vertical_shift" then
        local intensity = event.args:get(1)
        self.Pass2Material0["vIns"] = remap(intensity,-1,1)
    end
    if event.args:get(0) == "effects_adjust_color" then
        local intensity = event.args:get(1)
        self.Pass2Material0["edgeColOffset"] = remap(intensity,0,1)
    end
end


exports.ImageBusinessSlider = ImageBusinessSlider
return exports