--write by editor  EffectSDK:12.7.0 EngineVersion:12.7.0 EditorBuildTime:Nov__7_2022_11_34_02
--sliderVersion: 20210901  Lua generation date: Tue Nov  8 16:13:05 2022


local exports = exports or {}
local ImageBusinessSlider = ImageBusinessSlider or {}
ImageBusinessSlider.__index = ImageBusinessSlider


function ImageBusinessSlider.new(construct, ...)
    local self = setmetatable({}, ImageBusinessSlider)
    if construct and ImageBusinessSlider.constructor then
        ImageBusinessSlider.constructor(self, ...)
    end
    return self
end


local function remap(x, a, b)
    return x * (b - a) + a
end


function ImageBusinessSlider:onStart(sys)
    self.SeekModeScriptMaterial0 = sys.scene:findEntityBy("SeekModeScript"):getComponent("Renderer").material
    self.resultMaterial1 = sys.scene:findEntityBy("result"):getComponent("Renderer").material
    local intensity = 0.1
    self.SeekModeScriptMaterial0["size"] = remap(intensity,0,0.2)
    self.SeekModeScriptMaterial0["lineLength"] = remap(intensity,5.5,6)
    self.SeekModeScriptMaterial0["lineDis"] = remap(intensity,4.5,8)
end


function ImageBusinessSlider:onEvent(sys,event)
    if event.args:get(0) == "effects_adjust_size" then
        local intensity = event.args:get(1)
        self.SeekModeScriptMaterial0["size"] = remap(intensity,0,0.2)
        self.SeekModeScriptMaterial0["lineLength"] = remap(intensity,5.5,6)
        self.SeekModeScriptMaterial0["lineDis"] = remap(intensity,4.5,8)
    end
    if event.args:get(0) == "matting_stroke_adjust_color"  then
        local lineCol = event.args:get(1)
        self.resultMaterial1:setFloat("R",lineCol:get(1))
        self.resultMaterial1:setFloat("G",lineCol:get(2))
        self.resultMaterial1:setFloat("B",lineCol:get(3))
    end
end


exports.ImageBusinessSlider = ImageBusinessSlider
return exports