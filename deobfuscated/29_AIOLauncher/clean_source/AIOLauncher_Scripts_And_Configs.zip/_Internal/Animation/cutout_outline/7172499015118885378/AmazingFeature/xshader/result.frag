precision highp float;

varying vec2 uv;
uniform sampler2D inputImageTexture;
uniform sampler2D oriTex;
uniform sampler2D lineColTex;
uniform float colIns;
uniform vec4 u_ScreenParams;
uniform float R;
uniform float G;
uniform float B;
#define textureCoordinate uv

void main()
{
    float mask = texture2D(inputImageTexture,vec2(uv.x,1.0-uv.y)).r;
    vec4 oriCol = texture2D(oriTex,textureCoordinate);
    oriCol.rgb =mix(oriCol.rgb,vec3(R,G,B),mask); 
    oriCol.a = clamp(oriCol.a+mask,0.0,1.0);
    gl_FragColor = oriCol;
}
