precision highp float;

// attribute vec4 color;
attribute vec3 position;
attribute vec2 texcoord0;
varying vec2 fTexCoord;
varying vec4 screenPos;
uniform float ratio; 
varying float id;
varying vec2 oriUV;
uniform float lineDis;
uniform float lineLength;

// mat2 rotmat2(float dx,float dy){
//     float dxy=1./length(vec2(dx,dy));
//     float cosA=-dx*dxy;
//     float sinA=-dy*dxy;
//     return mat2(cosA,-sinA,
//                 sinA,cosA);
// }
// vec2 rot2(vec2 point,vec2 rotOri,float dx,float dy,float ratio) {
//     //return point;
//     vec2 temp=vec2(0.);
//     temp.x=point.x-rotOri.x;
//     temp.x=temp.x*ratio;
//     temp.y=point.y-rotOri.y;
//     vec2 tt = temp*rotmat2(dx,dy);
//     temp=mix(tt,temp,step(position.x,-1.0));
//     return vec2(temp.x/ratio,temp.y)+rotOri;

// }
void main()
{
    fTexCoord.x = (abs(mod(position.z,100.0))+texcoord0.x)*0.01;
    
    fTexCoord.y  =1.0-texcoord0.y;
    oriUV = texcoord0;
    // vec4 mycol = color;
    // float Xdis=(color.z-0.2)*10.;
    // float Ydis=(color.w-0.2)*10.;
    // screenPos=vec4(rot2(position.xy,color.xy,Xdis,Ydis,ratio),0.0,1.0);
    screenPos=vec4(position.xy,0.0,1.0);
    id = position.z;
    float flag = step(mod(id,lineDis+lineLength),lineLength);
    screenPos = mix(vec4(-2.,-2.,0.0,1.0),screenPos,flag);
    gl_Position = screenPos;
}
