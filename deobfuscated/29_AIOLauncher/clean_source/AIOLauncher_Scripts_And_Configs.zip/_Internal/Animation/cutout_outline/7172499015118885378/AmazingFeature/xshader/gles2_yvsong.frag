precision highp float;

varying vec2 fTexCoord;
varying vec4 screenPos;
varying vec2 oriUV;
uniform sampler2D mask;
uniform sampler2D oriimg;
uniform float alphaFactor;
uniform sampler2D sucaiText;
varying float id;
float smax(float a,float b,float k){
    float h=clamp((b-a)/k+0.5,0.,1.);
	return mix(a,b,h)+h*(1.-h)*k*.5;   
}
float smin(float a,float b,float k){
    float h=clamp((b-a)/k+0.5,0.,1.);
	return mix(b,a,h)-h*(1.-h)*k*.5;   
}
float sdCircle( in vec2 p, in float r ) 
{
    return length(p)-r;
}
float sdBox( vec2 p, vec2 b )
{
    vec2 d = abs(p)-b;
    return length(max(d,0.0)) + min(max(d.x,d.y),0.0);
}
float sdy(vec2 p ,float h)
{
    return abs(p.y)-h;
}
void main() 
{
    // gl_FragColor = lm_inverse_premult(texture2D(sucaiText, fTexCoord));
    vec2 newuv = oriUV-0.5;
    // float circle = sdCircle(newuv,0.4);
    // float box = sdBox(newuv,vec2(0.3,0.4));
    // float h = sdy(newuv,0.4);
    // float d =smax(h,circle,0.2);
    
    // // Time varying pixel color
    // float myD = smoothstep(0.1,0.0,d);
    // float flag = step(mod(id,25.),10.);
    // gl_FragColor = vec4(1.0);
    float d = smoothstep(0.5,0.48,length(newuv));
    gl_FragColor = vec4(d*vec3(1.0,0.0,0.),d);
    
    // gl_FragColor = vec4(smoothstep(0.3,0.2,length(newuv)));
}
