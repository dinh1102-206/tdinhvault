precision highp float;

varying vec2 fTexCoord;
varying vec4 screenPos;
varying vec2 uv;
const int MAX_SIZE = 100;
uniform vec2 u_CutoutPoints[MAX_SIZE];
uniform float u_NumCutoutPoints;
vec2 getKeyPointSafe(int index, int numKeyPoints) {
    int i = int(mix(float(index), 0., float(index >= numKeyPoints)));
    return u_CutoutPoints[i];
}
// Returns 1.0 if UV point is within cutout shape, 0.0 otherwise
// Utilizes point in polygon method described below:
// https://observablehq.com/@tmcw/understanding-point-in-polygon
float pointInPolygon(int numKeyPoints) {
    float inside = 0.;
    float x = uv.x;
    float y = uv.y;
    for (int i = 0; i < numKeyPoints; i++) {
        vec2 p1 = u_CutoutPoints[i];
        vec2 p2 = getKeyPointSafe(i + 1, numKeyPoints);
        vec2 pDiff = p2 - p1;
        float intersect = float(((p1.y > y) != (p2.y > y)) && (x < pDiff.x * (y - p1.y) / pDiff.y + p1.x));
        inside = mix(inside, 1. - inside, intersect);
    }
    return inside;
}
void main() 
{
    int numKeyPoints = int(u_NumCutoutPoints);
    float mask = pointInPolygon(numKeyPoints);
    gl_FragColor = vec4(mask);
    // gl_FragColor = vec4(1.0);
    
    // gl_FragColor = vec4(smoothstep(0.3,0.2,length(newuv)));
}
