local exports = exports or {}
local SeekModeScript = SeekModeScript or {}

SeekModeScript.__index = SeekModeScript
function SeekModeScript.new(construct, ...)
    local self = setmetatable({}, SeekModeScript)
    if construct and SeekModeScript.constructor then
        SeekModeScript.constructor(self, ...)
    end
    self.startTime = 0.0
    self.endTime = 3.0
    self.curTime = 0.0
    self.width = 0
    self.height = 0
    self.entityNum = 200
    self.oriSize = 0.10
    self.size = 0.1
    self.ratio = 0
    self.speed = 50
    self.lineLength = 10
    self.lineDis = 10
    self.flag = 1
    self.lastflag = 0
    self.pointNum = 0
    self.lastPointNum = {-100,-100,-100,-100,-100}
    self.lineLength = 100
    self.material = {}
    self.EntityArray = {}
    return self
end


local function myrand(p)
    local p1 = (p*124.)%1
    p1= p1 + (p1*(p1+22.22))
    return ((p1+p1)*p1)%1;
end

function SeekModeScript:getPoints(index)
    local result = self.dataTable:get("contours")
    local cutoutPointVec = Amaz.Vec2Vector()
    local numPoint = 0
    self.pointNum = 0
    if result then
        local findContourCount = result:size()
        if findContourCount ~= 0 then
            local width = self.dataTable:get("image_Width")
            local height = self.dataTable:get("image_Height")
            local scaleX = (width)/ (width-44)
            local scaleY = (height)/ (height-44)
            -- local scaleX = 1
            -- local scaleY = 1

            -- local dis = 1
            -- local contoursSize = result:size() - 1
            -- local maxIndex = 0
            -- local maxNum = 0
            -- for p=0 ,contoursSize do
            local contours = result:get(index)
            local num = contours:size() - 1
            local last =
                    contours:get(
                    math.mod(0.6*num, num)
                )       
            -- Amaz.LOGI("asdasd",num.."Ww"..self.curTime)
            for i = 0, num do
                if (1) then
                    local temp =
                        contours:get(
                        math.mod(i+0.6*num, num)
                    )
                    
                    local tempVec2 = last-temp
                    if(cutoutPointVec:size()<101) then
                    if(tempVec2.x*tempVec2.x+tempVec2.y*tempVec2.y)>self.lineLength then
                        local templast =contours:get(math.mod(i-1+0.6*num, num))
                        local lastVec2 = temp-templast
                        if(lastVec2.x*lastVec2.x+lastVec2.y*lastVec2.y)>30 then
                            -- numPoint=numPoint+1
                            local lastpointX = (templast.x / width - 0.5) * 2 * scaleX
                            local lastpointY = (1.0 - templast.y / height - 0.5) * 2 * scaleY
                            local lastpoint = Amaz.Vector2f(lastpointX*0.5+0.5, lastpointY*0.5+0.5)
                            cutoutPointVec:popBack()
                            cutoutPointVec:pushBack(lastpoint)
                        end
                        last=temp
                        numPoint=numPoint+1
                        local sucaipointX = (temp.x / width - 0.5) * 2 * scaleX
                        local sucaipointY = (1.0 - temp.y / height - 0.5) * 2 * scaleY
                        local sucaipoint = Amaz.Vector2f(sucaipointX*0.5+0.5, sucaipointY*0.5+0.5)
                        cutoutPointVec:pushBack(sucaipoint)
                        local temp = 7+15*myrand(i)
                        self.lineLength = temp*temp
                        -- Amaz.LOGI("asdasd",tempVec2.x*tempVec2.x+tempVec2.y*tempVec2.y)
                    end
                end
                    
                    
                    
                end
            end
            -- end
            self.pointNum = numPoint
        end
    end
    return cutoutPointVec , numPoint
end
function SeekModeScript:onUpdate(comp, detalTime)
    self.curTime = self.curTime + detalTime
    self:seekToTime(comp, self.curTime - self.startTime)
end

function SeekModeScript:onStart(comp)
    local w = Amaz.BuiltinObject:getInputTextureWidth()
    local h = Amaz.BuiltinObject:getInputTextureHeight()
    self.ratio = w / h
    -- self.animSeqCom = comp.entity.scene:findEntityBy("SeekModeScript"):getComponent("AnimSeqComponent")
    -- self.MeshEntity = comp.entity.scene:findEntityBy("SeekModeScript"):getComponent("MeshRenderer")
    self.EntityArray[1] =comp.entity.scene:findEntityBy("SeekModeScript_1")
    self.EntityArray[2] =comp.entity.scene:findEntityBy("SeekModeScript_2")
    self.EntityArray[3] =comp.entity.scene:findEntityBy("SeekModeScript_3")
    self.EntityArray[4] =comp.entity.scene:findEntityBy("SeekModeScript_4")
    self.EntityArray[5] =comp.entity.scene:findEntityBy("SeekModeScript_5")
    self.material[1] = comp.entity.scene:findEntityBy("SeekModeScript_1"):getComponent("MeshRenderer").material
    self.material[2] = comp.entity.scene:findEntityBy("SeekModeScript_2"):getComponent("MeshRenderer").material
    self.material[3] = comp.entity.scene:findEntityBy("SeekModeScript_3"):getComponent("MeshRenderer").material
    self.material[4] = comp.entity.scene:findEntityBy("SeekModeScript_4"):getComponent("MeshRenderer").material
    self.material[5] = comp.entity.scene:findEntityBy("SeekModeScript_5"):getComponent("MeshRenderer").material
    self.material1 = comp.entity.scene:findEntityBy("blur1"):getComponent("MeshRenderer").material
    -- self.MeshEntity.mesh = self.customMesh
    self.resultMaterial = comp.entity.scene:findEntityBy("result"):getComponent("MeshRenderer").material
    
    self.dataTable = comp.entity.scene:findEntityBy("table"):getComponent("TableComponent").table
    -- self.customMesh = self:createCustomMesh()
    self.material1:setTex("ori1Tex", Amaz.Texture2D())
    self.myMatting = Amaz.Texture2D()
    self.resultMaterial:setTex("mattingImg", self.myMatting)
end

function SeekModeScript:seekToTime(comp, time)
    for i = 1, 5 do
        self.EntityArray[i].visible = false
    end
    -- self.animSeqCom:seekToTime(time)
    local w = Amaz.BuiltinObject:getInputTextureWidth()
    local h = Amaz.BuiltinObject:getInputTextureHeight()
    if w ~= self.width or h ~= self.height then
        self.cameraRT = comp.entity.scene:findEntityBy("Camera_entity"):getComponent("Camera").renderTexture
        self.cameraRT.width = w
        self.cameraRT.height = h
        self.cameraRT2 = comp.entity.scene:findEntityBy("CamBlur"):getComponent("Camera").renderTexture
        self.cameraRT2.width = w
        self.cameraRT2.height = h
        self.width = w
        self.height = h
        self.ratio = w / h
        -- self.material:setFloat("ratio", self.ratio)
    end
    -- local tage = 1
    -- if h > w then
    --     tage = 0.75
    -- end
    -- self.material:setFloat("lineLength", self.lineLength)
    -- self.material:setFloat("lineDis", self.lineDis)
    -- self.lineLength = (50 + 150 * self.material:getFloat("lineLength"))
    -- self.size = self.oriSize / (self.ratio + 0.0001) * tage
    -- self.customMesh = self:createCustomMesh()
    -- self.MeshEntity.mesh = self.customMesh
    if self.dataTable:get("mask") then
        self.material1:getTex("ori1Tex"):storage(self.dataTable:get("mask"))
    end
    local result = self.dataTable:get("contours")
    if result then
        local findContourCount = result:size()
        if findContourCount<0.5 then

        end
        for i = 0, findContourCount-1 do
            local index = i
            self.EntityArray[index+1].visible = true
            local cutoutPointVec,pointNum = self:getPoints(index)
            if(math.abs(pointNum-self.lastPointNum[index+1])>0.5) then
                self.lastPointNum[index+1]=math.min(pointNum,100)
                self.material[index+1]:setVec2Vector("u_CutoutPoints", cutoutPointVec)
                self.material[index+1]:setFloat("u_NumCutoutPoints", pointNum)
            end
        end
    end
    -- Amaz.LOGI("asdasd",self.dataTable:get('image_Width'))
end

function SeekModeScript:onEvent(sys, event)
    if event.args:get(0) == "segMask"  then
        local bgMask = event.args:get(1)
        -- if(bgMask == nil) then
        --     Amaz.LOGI("YMLog","not nil")
        -- else
        --     Amaz.LOGI("YMLog","nil")
        -- end
        self.resultMaterial:getTex("mattingImg"):storage(bgMask)
    end
end

exports.SeekModeScript = SeekModeScript
return exports
