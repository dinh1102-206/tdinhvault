precision highp float;

varying vec2 uv;
uniform sampler2D inputImageTexture;
uniform sampler2D oriTex;
uniform sampler2D lineColTex;
uniform float colIns;
uniform vec4 u_ScreenParams;
uniform sampler2D mattingImg;
uniform float R;
uniform float G;
uniform float B;
uniform float alpha;
#define textureCoordinate uv

void main()
{
    float mask = texture2D(inputImageTexture,vec2(uv.x,1.0-uv.y)).r;
    vec4 oriCol = texture2D(oriTex,textureCoordinate);
    oriCol.rgb = clamp(oriCol.rgb/oriCol.a,0.0,1.0);
    vec3 resultCol =mix(oriCol.rgb,vec3(R,G,B),mask); 
    float mattingMask = texture2D(mattingImg,uv).r;
    resultCol = mix(resultCol,oriCol.rgb,mattingMask);
    gl_FragColor = vec4(resultCol,clamp(oriCol.a+mask*alpha,0.0,1.0));
    // gl_FragColor =vec4(1);
}
