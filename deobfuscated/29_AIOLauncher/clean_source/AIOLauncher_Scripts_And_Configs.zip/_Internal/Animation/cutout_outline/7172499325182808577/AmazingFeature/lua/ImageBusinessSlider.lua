--write by editor  EffectSDK:13.6.0 EngineVersion:13.6.0 EditorBuildTime:Mar_23_2023_00_42_43
--sliderVersion: 20210901  Lua generation date: Tue Aug  8 21:16:25 2023


local exports = exports or {}
local ImageBusinessSlider = ImageBusinessSlider or {}
ImageBusinessSlider.__index = ImageBusinessSlider


function ImageBusinessSlider.new(construct, ...)
    local self = setmetatable({}, ImageBusinessSlider)
    if construct and ImageBusinessSlider.constructor then
        ImageBusinessSlider.constructor(self, ...)
    end
    return self
end


local function remap(x, a, b)
    return x * (b - a) + a
end


function ImageBusinessSlider:onStart(sys)
    self.resultMaterial0 = sys.scene:findEntityBy("result"):getComponent("Renderer").material
end


function ImageBusinessSlider:onEvent(sys,event)
    if event.args:get(0) == "matting_stroke_adjust_color"  then
        local lineCol = event.args:get(1)
        self.resultMaterial0:setFloat("R",lineCol:get(1))
        self.resultMaterial0:setFloat("G",lineCol:get(2))
        self.resultMaterial0:setFloat("B",lineCol:get(3))
    end
    if event.args:get(0) == "effects_adjust_alpha"  then
        local ins = event.args:get(1)
        self.resultMaterial0:setFloat("alpha",ins)
    end
end


exports.ImageBusinessSlider = ImageBusinessSlider
return exports