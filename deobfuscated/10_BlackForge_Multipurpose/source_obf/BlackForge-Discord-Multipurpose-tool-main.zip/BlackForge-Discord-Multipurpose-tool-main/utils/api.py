# Paste Your sms Api's here in json format

