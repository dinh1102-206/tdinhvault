import os
import re
import sys
import shutil
import threading
from colorama import init, Style

init(autoreset=True)

if sys.platform.startswith('win'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except AttributeError:
        pass

RESET = Style.RESET_ALL

R1 = "\033[38;2;210;210;210m"
R2 = "\033[38;2;175;175;175m"
R3 = "\033[38;2;140;140;140m"
R4 = "\033[38;2;105;105;105m"
R5 = "\033[38;2;75;75;75m"
R6 = "\033[38;2;45;45;45m"

ROW_COLORS = [R1, R2, R3, R4, R5, R6]

WHITE  = "\033[38;2;250;250;250m"
SILVER = "\033[38;2;185;185;185m"
MUTED  = "\033[38;2;120;120;120m"
BORDER = "\033[38;2;100;100;100m"

SUCCESS = "\033[38;2;180;180;180m"
WARNING = "\033[38;2;255;170;40m"
DANGER  = "\033[38;2;80;80;80m"

ANSI_REGEX = re.compile(r'\033\[[0-9;]*m')
PRINT_LOCK = threading.Lock()

def get_term_width() -> int:
    try:
        return shutil.get_terminal_size((90, 24)).columns
    except Exception:
        return 90

def visible_len(text: str) -> int:
    return len(ANSI_REGEX.sub('', text))

def center_text(text: str, total_w: int = None) -> str:
    w = total_w or get_term_width()
    v_len = visible_len(text)
    margin = max(0, (w - v_len) // 2)
    return " " * margin + text

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

class BlackforgeUI:
    BOX_WIDTH = 78
    INNER_WIDTH = BOX_WIDTH - 4

    @classmethod
    def render_banner(cls, subtitle: str = ""):
        clear()
        print()

        figure = [
            "⠀⠀⠀⠀⣠⣤⣶⣶⣶⣤⣄⡀",
            "⠀⠀⣴⣾⣿⣿⣿⣿⣿⣧⡀⠈",
            "⠀⣼⣿⣿⣿⣿⣿⣿⣿⡿⠁⠀",
            "⢰⡿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀",
            "⠘⣽⡿⠿⠿⣿⣿⣿⣿⣿⣦⣤",
            "⠀⣟⠀⠀⠀⣸⣿⡏⠀⠀⠀⢹",
            "⠀⣿⣷⣶⣾⡿⠁⠙⣄⣀⣀⣠",
            "⠀⠙⠙⢿⡿⣷⣶⣤⣿⣿⡿⠿",
            "⠀⠀⠀⠺⡏⡏⡏⡏⡏⠉⠁⠀",
            "⠀⠀⠀⠀⠀⠀⠁⠁⠀⠀⠀⠀",
        ]

        forge_art = [
            "███████╗ ██████╗ ██████╗  ██████╗ ███████╗",
            "██╔════╝██╔═══██╗██╔══██╗██╔════╝ ██╔════╝",
            "█████╗  ██║   ██║██████╔╝██║  ███╗█████╗  ",
            "██╔══╝  ██║   ██║██╔══██╗██║   ██║██╔══╝  ",
            "██║     ╚██████╔╝██║  ██║╚██████╔╝███████╗",
            "╚═╝      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝",
        ]

        fig_rows  = len(figure)    
        forge_rows = len(forge_art) 
        gap = "   "  


        pad_top    = (fig_rows - forge_rows) // 2        # 2
        pad_bottom = fig_rows - forge_rows - pad_top     # 2
        forge_padded = ([""] * pad_top) + forge_art + ([""] * pad_bottom)

        forge_max_w = max(len(l) for l in forge_art)

        combined_lines = []
        for idx in range(fig_rows):
            col        = ROW_COLORS[min(idx, len(ROW_COLORS) - 1)]
            fig_part   = f"{col}{figure[idx]}{RESET}"
            forge_line = forge_padded[idx]
            if forge_line:
                forge_part = f"{col}{forge_line}{RESET}"
            else:
                forge_part = " " * forge_max_w
            combined_lines.append(fig_part + gap + forge_part)

        for line in combined_lines:
            print(center_text(line))

        print()
        BETA_TAG = f"{RESET}\033[38;2;210;210;210m\033[48;2;55;55;55m [ βETA VERSION  ] {RESET}"
        if subtitle:
            sub = f"{R5}► {RESET}{R2}{subtitle}{RESET}{R5} ◄{RESET}  {BETA_TAG}"
        else:
            sub = f"{R5}► {RESET}{R2}FORGE ULTIMATE MULTI-TOOL  |  BY LYNX MODZ{RESET}{R5} ◄{RESET}  {BETA_TAG}"
        print(center_text(sub))
        print()

    @classmethod
    def b_top(cls, title: str = "") -> str:
        if title:
            lbl = f" [ {title} ] "
            v = visible_len(lbl)
            l = (cls.INNER_WIDTH - v) // 2
            r = cls.INNER_WIDTH - v - l
            box = f"{BORDER}╔{'═' * l}{R2}{lbl}{BORDER}{'═' * r}╗{RESET}"
        else:
            box = f"{BORDER}╔{'═' * cls.INNER_WIDTH}╗{RESET}"
        return center_text(box)

    @classmethod
    def b_bottom(cls) -> str:
        return center_text(f"{BORDER}╚{'═' * cls.INNER_WIDTH}╝{RESET}")

    @classmethod
    def b_div(cls, label: str = "") -> str:
        if label:
            lbl = f" {label} "
            v = visible_len(lbl)
            l = (cls.INNER_WIDTH - v) // 2
            r = cls.INNER_WIDTH - v - l
            box = f"{BORDER}╠{'═' * l}{MUTED}{lbl}{BORDER}{'═' * r}╣{RESET}"
        else:
            box = f"{BORDER}╠{'═' * cls.INNER_WIDTH}╣{RESET}"
        return center_text(box)

    @classmethod
    def b_row(cls, text: str = "") -> str:
        p = max(0, cls.INNER_WIDTH - 4 - visible_len(text))
        box = f"{BORDER}║{RESET}  {text}{' ' * p}  {BORDER}║{RESET}"
        return center_text(box)

    @classmethod
    def log(cls, msg: str):
        with PRINT_LOCK:
            print(cls.b_row(msg))
