import os
import sys
import time
import hashlib
import platform
import requests
from typing import Dict, Optional
from ui import BlackforgeUI, R1, R2, R3, R4, R5, BORDER, WHITE, MUTED, SUCCESS, WARNING, DANGER, RESET, center_text
from tools.token_joiner import run_token_joiner
from tools.phone_spammer import run_spammer
from tools.spammer import run_spammer_msg
from tools.token_remover import run_token_purger
from tools.nuker import run_nuker
from tools.name import run_name_sniper

LYNX_OWNERID: str = "fb56b6a6-8c4a-4dcb-95f9-d0387ea0175b" # paste your LynxAuth Ower iD from https://lynxauth.qzz.io
LYNX_SECRET: str = "b50fb2cc3641d041046b0bf820908568"      # paste your LynxAuth APP Secret Key from https://lynxauth.qzz.io

class LynxAuthAPI:
    def __init__(self, ownerid: str, secret: str, api_url: str = "https://api.lynxauth.qzz.io"):
        if api_url.endswith("/"):
            api_url = api_url[:-1]
        self.ownerid = ownerid
        self.secret = secret
        self.api_url = f"{api_url}/api/1.0/user_login"

    @classmethod
    def get_hwid(cls) -> str:
        return hashlib.sha256(f"{platform.node()}-{platform.processor()}".encode()).hexdigest()

    def login(self, username: str, password: str) -> Dict:
        payload = {
            "ownerid": self.ownerid,
            "app_secret": self.secret,
            "username": username,
            "password": password,
            "hwid": self.get_hwid()
        }
        try:
            r = requests.post(self.api_url, json=payload, timeout=10)
            return r.json()
        except requests.exceptions.RequestException as e:
            return {"success": False, "message": f"Connection Error: {e}"}

class BlackForgeLauncher:
    def __init__(self):
        self.auth_data: Optional[Dict] = None

    def authenticate_user(self):
        auth = LynxAuthAPI(LYNX_OWNERID, LYNX_SECRET)
        hwid = auth.get_hwid()

        while True:
            BlackforgeUI.render_banner("LynxAuth Authentication")
            print(BlackforgeUI.b_top("Authentication Required"))
            print(BlackforgeUI.b_row())
            print(BlackforgeUI.b_row(f"{R1}HWID {BORDER}│ {WHITE}{hwid[:32]}...{RESET}"))
            print(BlackforgeUI.b_row())
            print(BlackforgeUI.b_bottom())
            print()

            u_prompt = center_text(f"{BORDER}╭──────────[ {R1}Username{RESET}{BORDER} ]──────────╮{RESET}")
            u_in = center_text(f"{BORDER}╰─────[ {R2}❯❯{RESET}{BORDER} ]{RESET} ")
            print(u_prompt)
            try:
                username = input(u_in).strip()
            except (KeyboardInterrupt, EOFError):
                print(f"\n\n{center_text('Bye!')}\n")
                sys.exit(0)

            if not username:
                continue

            p_prompt = center_text(f"{BORDER}╭──────────[ {R1}Password{RESET}{BORDER} ]──────────╮{RESET}")
            p_in = center_text(f"{BORDER}╰─────[ {R2}❯❯{RESET}{BORDER} ]{RESET} ")
            print(p_prompt)
            try:
                password = input(p_in).strip()
            except (KeyboardInterrupt, EOFError):
                print(f"\n\n{center_text('Bye!')}\n")
                sys.exit(0)

            print()
            print(center_text(f"{R2}Verifying credentials and HWID...{RESET}"))
            res = auth.login(username, password)

            if res.get("success") or res.get("status") == "success" or res.get("message") == "Logged in successfully!":
                info = res.get("info") or res.get("user_data") or res
                expiry = info.get("expiry") or info.get("expires") or res.get("expiry") or "Lifetime"
                self.auth_data = {
                    "username": username,
                    "expiry": expiry,
                    "raw": res
                }
                print()
                print(center_text(f"{SUCCESS}✔ Login Successful! Expiry: {WHITE}{expiry}{RESET}"))
                time.sleep(1.2)
                break
            else:
                msg = res.get("message", "Authentication failed")
                print()
                print(center_text(f"{DANGER}✗ {msg}{RESET}"))
                time.sleep(1.5)

    def start(self):
        self.authenticate_user()

        while True:
            BlackforgeUI.render_banner()
            
            print(BlackforgeUI.b_top("Control Panel"))
            print(BlackforgeUI.b_row())
            
            usr = self.auth_data.get("username", "User")
            exp = self.auth_data.get("expiry") or "Lifetime"
            print(BlackforgeUI.b_row(f"{R1}Account  {BORDER}│ {WHITE}{usr}{RESET} {BORDER}• Expiry: {R2}{exp}{RESET}"))
            print(BlackforgeUI.b_row(f"{R1}Platform {BORDER}│ {WHITE}Black-Forge Multi-Tool v1.0{RESET}"))
            
            print(BlackforgeUI.b_row())
            print(BlackforgeUI.b_div("Tools Available"))
            print(BlackforgeUI.b_row())
            
            print(BlackforgeUI.b_row(f"  {BORDER}╭──[{R2} 1 {BORDER}]──{RESET} {WHITE}Discord Token Joiner{RESET}   {MUTED}─── Join tokens to server{RESET}"))
            print(BlackforgeUI.b_row(f"  {BORDER}╭──[{R2} 2 {BORDER}]──{RESET} {WHITE}Phone Bomber / Spammer{RESET} {MUTED}─── SMS/Call flooding utility{RESET}"))
            print(BlackforgeUI.b_row(f"  {BORDER}╭──[{R2} 3 {BORDER}]──{RESET} {WHITE}Discord Msg Spammer{RESET}    {MUTED}─── Spam messages with tokens{RESET}"))
            print(BlackforgeUI.b_row(f"  {BORDER}╭──[{R2} 4 {BORDER}]──{RESET} {WHITE}Token Check{RESET}           {MUTED}─── Remove invalid tokens from file{RESET}"))
            print(BlackforgeUI.b_row(f"  {BORDER}╭──[{R2} 5 {BORDER}]──{RESET} {WHITE}Discord Server Nuker{RESET}   {MUTED}─── Wipe channels & blast msgs{RESET}"))
            print(BlackforgeUI.b_row(f"  {BORDER}╭──[{R2} 6 {BORDER}]──{RESET} {WHITE}Name Sniper{RESET}            {MUTED}─── Find available Discord names{RESET}"))
            print(BlackforgeUI.b_row(f"  {BORDER}╭──[{R2} 7 {BORDER}]──{RESET} {WHITE}Exit Console{RESET}           {MUTED}─── Terminate session and close{RESET}"))
            
            print(BlackforgeUI.b_row())
            print(BlackforgeUI.b_bottom())
            print()

            prompt_line = center_text(f"{BORDER}╭──────────[ {R1}Choose Option{RESET}{BORDER} ]──────────╮{RESET}")
            sub_prompt  = center_text(f"{BORDER}╰─────[ {R2}❯❯{RESET}{BORDER} ]{RESET} ")
            print(prompt_line)
            try:
                cmd = input(sub_prompt).strip()
            except (KeyboardInterrupt, EOFError):
                print(f"\n\n{center_text('Goodbye!')}\n")
                sys.exit(0)

            if cmd == "1":
                run_token_joiner(self.auth_data)
            elif cmd == "2":
                run_spammer()
            elif cmd == "3":
                run_spammer_msg(self.auth_data)
            elif cmd == "4":
                run_token_purger(self.auth_data)
            elif cmd == "5":
                run_nuker(self.auth_data)
            elif cmd == "6":
                run_name_sniper(self.auth_data)
            elif cmd == "7":
                print(f"\n{center_text('Goodbye!')}\n")
                time.sleep(0.5)
                sys.exit(0)
            else:
                print(f"\n{center_text(f'{WARNING}Please enter 1–7.{RESET}')}\n")
                time.sleep(0.5)

if __name__ == "__main__":
    launcher = BlackForgeLauncher()
    launcher.start()
