<h1 align="center">Black Forge</h1>

<p align="center">
  <a href="https://ibb.co/n8rcr4fK"><img src="https://i.ibb.co/0VqMq1Zz/Screenshot-2026-08-14-214604.png" alt="Black Forge Banner" border="0"></a>
</p>

> [!WARNING]
> **Official Download Source Only:** Do not download any executable (`.exe`) files from any other link or source. Only download from this official repository. 
> 
> *This tool is for educational and testing purposes. The developer (Lynx Modz) is not responsible for any misuse.*

> [!IMPORTANT]
> **Example Beta Build & License Info**
> * This is **not the actual full tool build**. It is a public, free example/beta version of the tool.
> * The full version and source code distribution are not available for free. You must contact the developer for a paid license/key.
> * **Free Beta Login Credentials (Valid for 28 days):**
>   * **Username:** `blackforge@user`
>   * **Password:** `free97`

> [!NOTE]
> **Security & Safety:**
> The executable built and provided here is 100% clean and malware-free from the developer's side. However, for standard safety practices, run this software at your own risk.

Black Forge is a CLI-based multi-tool with a simple text-based interface. It has built-in features to test Discord APIs, manage tokens, and test message sending.

It uses **LynxAuth** for login. You need a username and password linked to your HWID to use it.

---

## 📺 Links
<div align="center">

[![Discord Support](https://img.shields.io/badge/Discord-Support-5865F2?style=for-the-badge&logo=discord&logoColor=white)](https://dsc.gg/lynx-modz)
[![YouTube Channel](https://img.shields.io/badge/YouTube-Channel-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@LynxModz)
[![Star on GitHub](https://img.shields.io/badge/Star-Repository-181717?style=for-the-badge&logo=github&logoColor=white)](#)

</div>

---

## 📦 No Extra setup required.
You do not need to install any .net libraries to run this tool !
1. Download the pre-built `BlackForge.exe` from the Releases section or example given here.
2. Put the `setup` folder in the same place as the EXE.
3. Run `BlackForge.exe`.

---

## 🛠️ Features inside the tool

### 1. Discord Token Joiner
Joins multiple user accounts (using their tokens) into a server.
* Needs tokens in `setup/tokens.txt` (one per line).
* Needs bot details in `setup/config.json`.

### 2. Phone Spammer
Sends SMS tests to a target phone number using online web APIs.
* Needs a valid phone number.

### 3. Discord Msg Spammer
Sends messages to a Discord channel using your loaded tokens.
* Rotates tokens to avoid rate limits.
* Loads message list from `setup/msg.txt`.

### 4. Token Checker
Checks if your Discord tokens are still valid or expired.
* Reads from `setup/tokens.txt`.
* Cleans up expired tokens and saves the working ones back.

### 5. Server Nuker
Deletes channels, roles, and sends spam messages in a Discord server.
* Needs a Discord bot token with Administrator permission in `setup/config.json`.

### 6. Name Sniper
Checks if Discord handles (usernames) are available.
* Can generate random handles or check from a list.

---

## ⚙️ Folder Structure Example
When you share or run the tool, keep this structure:
```
📁 Black Forge/
├── BlackForge.exe      (The executable file)
└── 📁 setup/           (Folder with setting files)
    ├── config.json     (Contains bot token and client ID)
    ├── tokens.txt      (Contains user tokens)
    └── msg.txt         (Contains message list for spammer)
```

---

## ⚖️ Legal Notice
This program is distributed in the hope that it will be useful for testing and educational purposes. By using this tool, you agree that you are fully responsible for your actions. Read the [LICENSE](LICENSE) file for more information.
